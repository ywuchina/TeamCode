from sacf.datasets.threedmatch_dataset import ThreeDMatchDataset
from torch.utils.data import DataLoader
from sacf.datasets.collate import CollateFunc

class ThreeDMatchDataModule():
    def __init__(self, root, num_points):
        self.root = root
        self.num_points = num_points
        self.collate_fn = CollateFunc()

    def train_loader(self):
        self.train_set = ThreeDMatchDataset(self.root, "train", num_points=self.num_points)
        return DataLoader(self.train_set,
                          pin_memory=True,
                          batch_size=1,
                          collate_fn=self.collate_fn,
                          num_workers=4,
                          shuffle=True,
                          drop_last=True)

    def val_loader(self):
        self.val_set = ThreeDMatchDataset(self.root, "val", num_points=self.num_points)
        return DataLoader(self.val_set,
                          pin_memory=True,
                          batch_size=1,
                          collate_fn=self.collate_fn,
                          num_workers=4,
                          shuffle=True)

    def test_loader(self):
        self.test_set = ThreeDMatchDataset(self.root, "test",
                                           min_scale=1., max_scale=1.,
                                           rotation_range=0,
                                           num_points=self.num_points)
        return DataLoader(self.test_set,
                          pin_memory=True,
                          batch_size=1,
                          collate_fn=self.collate_fn,
                          num_workers=4,
                          shuffle=False)

if __name__== '__main__':
    
    from types import SimpleNamespace
    path2data = r'/hy-tmp/threedmatch'
    config = SimpleNamespace(
        voxel_size=0.05,
        min_scale=0.8,
        max_scale=1.2,
    )
    threshold_rte = 0.3
    threshold_rre = 15
    data_module = ThreeDMatchDataModule(path2data,num_points=4096)
    train_loader = data_module.train_loader()

    for it, batch in enumerate(train_loader):
        src = batch['src'].float()
        a = batch['a'].float()
        true_attention = batch['attention'].float()
        # indices1 = batch['indices1'].float()
        # indices2 =  batch['indices2'].float()
        R = batch['rotation'].float()
        T = batch['translation'].float()
        Rinv = batch['inv_rotation'].float()
        Tinv = batch['inv_translation'].float()

        print(src.shape)
        print(a.shape)
        # print(raw_src[0])
        print(true_attention.shape)
        # print(indices1[0])
        # print(indices2[0])
        print(R.shape)
        print(T.shape)
        print(Rinv.shape)
        print(Tinv.shape)
       
        break