from .network import get_network

__all__ = ["get_network"]
