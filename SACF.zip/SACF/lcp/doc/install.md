# Installation

## Dependencies

- [Sacred](https://github.com/IDSIA/sacred)
- pymongo
- Pytorch

## Library installation
```
pip install -ve /path/to/LightConvPoint/
```