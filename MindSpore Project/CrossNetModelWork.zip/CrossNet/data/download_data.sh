gdown https://drive.google.com/uc?id=1F9XIhF1qngLt-GtdnOnXiTsXH84YtrbC
gdown https://drive.google.com/uc?id=1UUY729-4VK_igjKUzLn_ygm3LxwW23pX
gdown https://drive.google.com/uc?id=1r3nJ6gEu6cL59h7cIfMrBeY5p1P_JiIV
gdown https://drive.google.com/uc?id=15lmtRaHvVIPLOp_o7rms8e6VQp_en8WF
gdown https://drive.google.com/uc?id=1-Yhqgi7KH6guIej_4X8pciiybQB4pBWQ

tar -xzvf shapenet.tar.gz
tar -xzvf shapenet_render.tar.gz
tar -xzvf scanobjectnn.tar.gz
tar -xzvf modelnet40.tar.gz
tar -xzvf shapenet_part.tar.gz