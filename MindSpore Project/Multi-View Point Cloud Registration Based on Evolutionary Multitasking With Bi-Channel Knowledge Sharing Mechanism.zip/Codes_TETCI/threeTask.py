import numpy as np
# import mindspore.numpy as np
import open3d as o3d
import copy
import time
import math
from utils import addGaussian
from utils import SE3
from utils import Sample
from utils.RandomNum import generate_exclusive_numbers

file_id = 10

def load_data():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\bunny\bunny_aligned_0.05\bun090.pcd')
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\bunny\bunny_aligned_0.05\bun180.pcd')
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\bunny\bunny_aligned_0.05\top2.pcd')
    # o3d.visualization.draw_geometries([pc1,pc2,pc3])
    return [pc1, pc2, pc3]

# 循环配准，1->2, 2->3, 3->1，3个任务，每个任务都有两个损失函数，一共相当于6个任务
class Solution:
    def __init__(self, pop_size, clouds, range_angles, range_shifts, F):
        self.pop_size = pop_size    # 每个种群中的个体数
        self.cloud1 = clouds[0]
        self.cloud2 = clouds[1]
        self.cloud3 = clouds[2]
        self.num1 = len(np.asarray(self.cloud1.points))
        self.num2 = len(np.asarray(self.cloud2.points))
        self.num3 = len(np.asarray(self.cloud3.points))
        self.range_angles = range_angles
        self.range_shifts = range_shifts
        self.F = F
        # k_pop1和k_pop2分别用来保存func1和func2中的个体
        self.k_pop1 = self.__init_k_pop()   # [[60, 6], [60, 6], [60, 6]]
        self.k_pop2 = self.__init_k_pop()   # [[60, 6], [60, 6], [60, 6]]
        # self.k_pop2[0][0] = np.array([5, 0, 0, 0, 0, 0])
        # self.k_pop2[1][0] = np.array([0, 5, 0, 0, 0, 0])
        # self.k_pop2[2][0] = np.array([0, 0, 5, 0, 0, 0])
        # self.k_pop2[0][0] = np.array([-0.20240782, -43.03591279, 0.336108, -13.5276678,
        #                0.86436926, -7.30507329])
        # self.k_pop2[1][0] = np.array([70.32870799, 16.87760707, 152.65864486, 16.28930877,
        #                                                  22.42971455, -36.25707591])
        # self.k_pop2[2][0] = np.array(
        #             [37.85791525, -57.07912635, -133.89859021, 0.81222677,
        #              42.14947298, -9.67048858])
        self.k_loss1 = []  # [[60], [60], [60]]
        self.k_loss2 = []  # [[60], [60], [60]]
        self.k_best_loss1 = []   # [3],保存每代最小的损失1
        self.k_best_loss2 = []   # [3],保存每代最小的损失2
        self.k_best_individual1 = [] # [3],保存每代每个任务中在损失1上最好的个体
        self.k_best_individual2 = [] # [3],保存每代每个任务中在损失2上最好的个体
        self.k_best_individuals1 = []    # 因为差分进化的变异策略需要用到最好的个体，只使用最好的一个个体不太合适，保存最好的前x个个体
        self.k_best_individuals2 = []    # 因为差分进化的变异策略需要用到最好的个体，只使用最好的一个个体不太合适，保存最好的前x个个体
        self.g_best_losses1 = [[], [], []]  # 用于保存函数1的损失，一代只保存一个最好的
        self.g_best_losses2 = [[], [], []]  # 用于保存函数2的损失，一代只保存一个最好的

    def __init_k_pop(self):
        k_pop = []
        for i in range(3):
            rotations = self.range_angles[0] + (self.range_angles[1] - self.range_angles[0]) * np.random.random((self.pop_size, 3))
            shifts = self.range_shifts[0] + (self.range_shifts[1] - self.range_shifts[0]) * np.random.random((self.pop_size, 3))
            pop_i = np.concatenate((rotations, shifts), axis=1)
            k_pop.append(pop_i)
        return k_pop

    def MSE_threshold(self, pop, cloud_s, cloud_t):
        losses = []
        trans = SE3.SE3(pop)
        num_s = len(np.asarray(cloud_s.points))
        num_t = len(np.asarray(cloud_t.points))
        for i in range(len(pop)):
            ps_copy = copy.deepcopy(cloud_s)
            ps_copy.transform(trans[i])
            distances = ps_copy.compute_point_cloud_distance(cloud_t)
            distances = np.asarray(distances)
            distances[distances > self.range_shifts[1] * 0.1] = self.range_shifts[1] * 0.1
            loss = np.sum(distances) / num_s
            losses.append(loss)
            # 加上下面这段代码就变成使用chamfer distance
            # distances2 = cloud_t.compute_point_cloud_distance(ps_copy)
            # distances2 = np.asarray(distances2)
            # distances2[distances2 > self.range_shifts[1] * 0.1] = self.range_shifts[1] * 0.1
            # loss2 = np.sum(distances2) / num_t
            # losses.append(loss + loss2)
        losses = np.array(losses)
        return losses

    def Overlap_ratio(self, g, task_id, pop, cloud_s, cloud_t, threshold):
        losses = []
        trans = SE3.SE3(pop)
        num_s = len(np.asarray(cloud_s.points))
        num_t = len(np.asarray(cloud_t.points))
        for i in range(len(pop)):
            ps_copy = copy.deepcopy(cloud_s)
            ps_copy.transform(trans[i])
            distances = ps_copy.compute_point_cloud_distance(cloud_t)
            distances = np.asarray(distances)
            num_overlap_points = np.sum(distances <= threshold)
            # 用的是双向重叠率，所以反过来也计算一遍
            distances2 = cloud_t.compute_point_cloud_distance(ps_copy)
            distances2 = np.asarray(distances2)
            num_overlap_points2 = np.sum(distances2 <= threshold)
            overlap_ratio = (num_overlap_points + num_overlap_points2) / (num_s + num_t)
            loss = 1 - overlap_ratio
            if g >= 0:
                if task_id == 0:
                    com_mat = np.dot(SE3.SE3_single(self.k_best_individual2[2]), np.dot(SE3.SE3_single(self.k_best_individual2[1]), trans[i]))
                elif task_id == 1:
                    com_mat = np.dot(SE3.SE3_single(self.k_best_individual2[2]), np.dot(trans[i], SE3.SE3_single(self.k_best_individual2[0])))
                else:
                    com_mat = np.dot(trans[i], np.dot(SE3.SE3_single(self.k_best_individual2[1]), SE3.SE3_single(self.k_best_individual2[0])))
                com_mat = com_mat - np.eye(4)
                f_norm = np.linalg.norm(com_mat, ord='fro')
                loss = loss + 0.05 * (1 - math.exp(- 2 * f_norm)) / (1 + math.exp(- 2 * f_norm))
            losses.append(loss)
        losses = np.array(losses)
        return losses

    def save_best(self, best_ratio):
        for i in range(3):
            loss1_i = self.k_loss1[i]
            loss2_i = self.k_loss2[i]
            rank1 = np.argsort(loss1_i)
            rank2 = np.argsort(loss2_i)
            self.k_best_loss1.append(np.min(loss1_i))
            self.k_best_loss2.append(np.min(loss2_i))
            self.k_best_individual1.append(self.k_pop1[i][rank1[0]])
            self.k_best_individual2.append(self.k_pop2[i][rank2[0]])
            self.k_best_individuals1.append(self.k_pop1[i][rank1[: int(self.pop_size * best_ratio)]])
            self.k_best_individuals2.append(self.k_pop2[i][rank2[: int(self.pop_size * best_ratio)]])
            self.g_best_losses1[i].append(self.k_best_loss1[i])
            self.g_best_losses2[i].append(self.k_best_loss2[i])

    def combine_trans(self, tran1, tran2):
        t1 = SE3.SE3_single(tran1)
        t2 = SE3.SE3_single(tran2)
        t = np.linalg.inv(np.dot(t2, t1))
        return SE3.transformationMatrixToVectors(t)

    def mutate_rand1(self, transfer_prob1=0.5, transfer_prob2=0.5, best_ratio=0.1):
        k_mutant1 = []
        k_mutant2 = []
        for i in range(3):
            pop1_i = copy.deepcopy(self.k_pop1[i])
            pop2_i = copy.deepcopy(self.k_pop2[i])
            randoms1 = generate_exclusive_numbers(self.pop_size, 3)
            randoms2 = generate_exclusive_numbers(self.pop_size, 3)
            mutant1_i = pop1_i[randoms1[:, 0]] + self.F * (pop1_i[randoms1[:, 1]] - pop1_i[randoms1[:, 2]])
            mutant2_i = pop2_i[randoms2[:, 0]] + self.F * (pop2_i[randoms2[:, 1]] - pop2_i[randoms2[:, 2]])
            random_ids = np.random.randint(0, self.pop_size, 2 * int(self.pop_size * best_ratio))
            # 满足信息交互条件1，不同任务间信息交换
            if np.random.random() <= transfer_prob1:
                mutant1_i[random_ids[: int(len(random_ids) / 2)]] = copy.deepcopy(self.combine_trans(self.k_best_individual2[(i + 1) % 3],
                                                                                       self.k_best_individual2[(i + 2) % 3]))
                mutant2_i[random_ids[: int(len(random_ids) / 2)]] = copy.deepcopy(self.combine_trans(self.k_best_individual2[(i + 1) % 3],
                                                                                       self.k_best_individual2[(i + 2) % 3]))
            # 满足信息交互条件2，同一个任务的两个不同损失间信息交换
            if np.random.random() <= transfer_prob2:
                # 只使用简单任务往难任务传递信息的策略
                mutant1_i[random_ids[int(len(random_ids) / 2) :]] = copy.deepcopy(self.k_best_individuals2[i])
                mutant2_i[random_ids[int(len(random_ids) / 2) :]] = copy.deepcopy(self.k_best_individuals1[i])
            k_mutant1.append(mutant1_i)
            k_mutant2.append(mutant2_i)
        return k_mutant1, k_mutant2

    def mutate_best1(self, transfer_prob1=0.5, transfer_prob2=0.5, best_ratio=0.1):
        k_mutant1 = []
        k_mutant2 = []
        for i in range(3):
            pop1_i = self.k_pop1[i]
            pop2_i = self.k_pop2[i]
            randoms1 = generate_exclusive_numbers(self.pop_size, 2)
            randoms2 = generate_exclusive_numbers(self.pop_size, 2)
            best_individuals1_i = self.k_best_individuals1[i]
            best_individuals2_i = self.k_best_individuals2[i]
            best_ids1 = np.random.randint(0, int(self.pop_size * best_ratio), self.pop_size)
            best_ids2 = np.random.randint(0, int(self.pop_size * best_ratio), self.pop_size)
            mutant1_i = best_individuals1_i[best_ids1] + self.F * (pop1_i[randoms1[:, 0]] - pop1_i[randoms1[:, 1]])
            mutant2_i = best_individuals2_i[best_ids2] + self.F * (pop2_i[randoms2[:, 0]] - pop2_i[randoms2[:, 1]])
            random_ids = np.random.randint(0, self.pop_size, 2 * int(self.pop_size * best_ratio))
            if np.random.random() <= transfer_prob1:
                mutant1_i[random_ids[: int(len(random_ids) / 2)]] = copy.deepcopy(self.combine_trans(self.k_best_individual2[(i + 1) % 3],
                                                                                       self.k_best_individual2[(i + 2) % 3]))
                mutant2_i[random_ids[: int(len(random_ids) / 2)]] = copy.deepcopy(self.combine_trans(self.k_best_individual2[(i + 1) % 3],
                                                                                       self.k_best_individual2[(i + 2) % 3]))
            if np.random.random() <= transfer_prob2:
                mutant1_i[random_ids[int(len(random_ids) / 2) :]] = copy.deepcopy(self.k_best_individuals2[i])
                mutant2_i[random_ids[int(len(random_ids) / 2) :]] = copy.deepcopy(self.k_best_individuals1[i])
            k_mutant1.append(mutant1_i)
            k_mutant2.append(mutant2_i)
        return k_mutant1, k_mutant2

    def SBX(self, k_mutant1, k_mutant2, n=3):
        new_k_pop11 = []
        new_k_pop12 = []
        new_k_pop21 = []
        new_k_pop22 = []
        for i in range(3):
            new_pop11_i = []
            new_pop12_i = []
            new_pop21_i = []
            new_pop22_i = []
            pop1_i = self.k_pop1[i]
            pop2_i = self.k_pop2[i]
            mutant1_i = k_mutant1[i]
            mutant2_i = k_mutant2[i]
            # 生成与父代相同数目的个体还是生成2倍于父代的个体
            rand_perm = np.random.permutation(self.pop_size)
            for j in range(self.pop_size):
                k = j
                u = np.random.random(6)
                beta = np.zeros(6)
                beta[u <= 0.5] = (2 * u[u <= 0.5]) ** (1 / (n + 1))
                beta[u > 0.5] = (1 / (2 - 2 * u[u > 0.5])) ** (1 / (n + 1))
                # c1 = 0.5 * (parent1 + parent2) - 0.5 * beta * (parent2 - parent1)
                # c2 = 0.5 * (parent1 + parent2) + 0.5 * beta * (parent2 - parent1)
                # u = np.random.uniform()
                # if u <= 0.5:
                #     beta = (2 * u) ** (1 / (n + 1))
                # else:
                #     beta = (1 / (2 - 2 * u)) ** (1 / (n + 1))
                c11 = 0.5 * (pop1_i[k] + mutant1_i[k]) - 0.5 * beta * (mutant1_i[k] - pop1_i[k])
                c12 = 0.5 * (pop1_i[k] + mutant1_i[k]) + 0.5 * beta * (mutant1_i[k] - pop1_i[k])
                c21 = 0.5 * (pop2_i[k] + mutant2_i[k]) - 0.5 * beta * (mutant2_i[k] - pop2_i[k])
                c22 = 0.5 * (pop2_i[k] + mutant2_i[k]) + 0.5 * beta * (mutant2_i[k] - pop2_i[k])
                new_pop11_i.append(c11.tolist())
                new_pop12_i.append(c12.tolist())
                new_pop21_i.append(c21.tolist())
                new_pop22_i.append(c22.tolist())
            new_k_pop11.append(np.array(new_pop11_i))
            new_k_pop12.append(np.array(new_pop12_i))
            new_k_pop21.append(np.array(new_pop21_i))
            new_k_pop22.append(np.array(new_pop22_i))
        return new_k_pop11, new_k_pop12, new_k_pop21, new_k_pop22

    def param_adjust(self, k_pop):
        adjusted_pop = []
        for i in range(3):
            pop_i = k_pop[i]
            angles = pop_i[:, 0:3]
            shifts = pop_i[:, 3:6]
            angles[self.range_angles[0] - angles > self.range_angles[1] * 0.1] = self.range_angles[0] + (self.range_angles[1] - self.range_angles[0]) * np.random.random((np.sum(self.range_angles[0] - angles > self.range_angles[1] * 0.1)))
            angles[angles - self.range_angles[1] > self.range_angles[1] * 0.1] = self.range_angles[0] + (self.range_angles[1] - self.range_angles[0]) * np.random.random((np.sum(angles - self.range_angles[1] > self.range_angles[1] * 0.1)))
            angles[angles < self.range_angles[0]] = self.range_angles[0]
            angles[angles > self.range_angles[1]] = self.range_angles[1]
            shifts[self.range_shifts[0] - shifts > self.range_shifts[1] * 0.1] = self.range_shifts[0] + (self.range_shifts[1] - self.range_shifts[0]) * np.random.random((np.sum(self.range_shifts[0] - shifts > self.range_shifts[1] * 0.1)))
            shifts[shifts - self.range_shifts[1] > self.range_shifts[1] * 0.1] = self.range_shifts[0] + (self.range_shifts[1] - self.range_shifts[0]) * np.random.random((np.sum(shifts - self.range_shifts[1] > self.range_shifts[1] * 0.1)))
            shifts[shifts < self.range_shifts[0]] = self.range_shifts[0]
            shifts[shifts > self.range_shifts[1]] = self.range_shifts[1]
            adjusted_pop.append(np.concatenate((angles, shifts), axis=1))
        return adjusted_pop

    def select(self, loss_id, k_pop, k_loss, new_k_pop1, new_k_loss1, new_k_pop2, new_k_loss2, best_ratio=0.1):
        k_pops = []
        k_losses = []
        best_k_loss = []
        best_k_individual = []
        best_k_individuals = []
        for i in range(3):
            pop_i = k_pop[i]
            loss_i = k_loss[i]
            new_pop1_i = new_k_pop1[i]
            new_loss1_i = new_k_loss1[i]
            new_pop2_i = new_k_pop2[i]
            new_loss2_i = new_k_loss2[i]
            for j in range(self.pop_size):
                rank_j = np.argsort([loss_i[j], new_loss1_i[j], new_loss2_i[j]])
                if rank_j[0] == 1:
                    pop_i[j] = copy.deepcopy(new_pop1_i[j])
                    loss_i[j] = new_loss1_i[j]
                elif rank_j[0] == 2:
                    pop_i[j] = copy.deepcopy(new_pop2_i[j])
                    loss_i[j] = new_loss2_i[j]
            k_pops.append(pop_i)
            k_losses.append(loss_i)
            best_k_loss.append(np.min(loss_i))
            best_k_individual.append(pop_i[np.argmin(loss_i)])
            best_k_individuals.append(pop_i[np.argsort(loss_i)[:int(self.pop_size * best_ratio)]])
        if loss_id == 1:
            self.k_best_loss1 = best_k_loss
            self.k_best_individual1 = best_k_individual
            self.k_best_individuals1 = best_k_individuals
            self.g_best_losses1[0].append(self.k_best_loss1[0])
            self.g_best_losses1[1].append(self.k_best_loss1[1])
            self.g_best_losses1[2].append(self.k_best_loss1[2])
        else:
            self.k_best_loss2 = best_k_loss
            self.k_best_individual2 = best_k_individual
            self.k_best_individuals2 = best_k_individuals
            self.g_best_losses2[0].append(self.k_best_loss2[0])
            self.g_best_losses2[1].append(self.k_best_loss2[1])
            self.g_best_losses2[2].append(self.k_best_loss2[2])
        return k_pops, k_losses

    def select2(self, loss_id, k_pop, k_loss, new_k_pop1, new_k_loss1, new_k_pop2, new_k_loss2, best_ratio=0.1):
        k_pops = []
        k_losses = []
        best_k_loss = []
        best_k_individual = []
        best_k_individuals = []
        for i in range(3):
            pop_i = k_pop[i]
            loss_i = k_loss[i]
            new_pop1_i = new_k_pop1[i]
            new_loss1_i = new_k_loss1[i]
            new_pop2_i = new_k_pop2[i]
            new_loss2_i = new_k_loss2[i]
            pop = np.concatenate((pop_i, new_pop1_i), axis=0)
            pop = np.concatenate((pop, new_pop2_i), axis=0)
            loss = np.concatenate((loss_i, new_loss1_i))
            loss = np.concatenate((loss, new_loss2_i))
            rank = np.argsort(loss)
            pop = pop[rank[:self.pop_size]]
            loss = loss[rank[:self.pop_size]]
            k_pops.append(pop)
            k_losses.append(loss)
            best_k_loss.append(np.min(loss))
            best_k_individual.append(pop[np.argmin(loss)])
            best_k_individuals.append(pop[np.argsort(loss)[:int(self.pop_size * best_ratio)]])
        if loss_id == 1:
            self.k_best_loss1 = best_k_loss
            self.k_best_individual1 = best_k_individual
            self.k_best_individuals1 = best_k_individuals
            self.g_best_losses1[0].append(self.k_best_loss1[0])
            self.g_best_losses1[1].append(self.k_best_loss1[1])
            self.g_best_losses1[2].append(self.k_best_loss1[2])
        else:
            self.k_best_loss2 = best_k_loss
            self.k_best_individual2 = best_k_individual
            self.k_best_individuals2 = best_k_individuals
            self.g_best_losses2[0].append(self.k_best_loss2[0])
            self.g_best_losses2[1].append(self.k_best_loss2[1])
            self.g_best_losses2[2].append(self.k_best_loss2[2])
        return k_pops, k_losses

    def __call__(self, max_generations, threshold):
        best_ratio = 0.1
        transfer_prob1 = 0.5
        transfer_prob2 = 0.5
        # n=1.0时效果普遍比2/3/5好一点，2和3效果接近，3稍好一点点，5效果最差
        # 可以尝试把n由小变大，开始产生的解离两个父代远一点，后面产生的解离两个父代近一点
        n = 2.0
        self.k_loss1.append(self.MSE_threshold(self.k_pop1[0], self.cloud1, self.cloud2))
        self.k_loss1.append(self.MSE_threshold(self.k_pop1[1], self.cloud2, self.cloud3))
        self.k_loss1.append(self.MSE_threshold(self.k_pop1[2], self.cloud3, self.cloud1))
        self.k_loss2.append(self.Overlap_ratio(-1, 0, self.k_pop2[0], self.cloud1, self.cloud2, threshold))
        self.k_loss2.append(self.Overlap_ratio(-1, 1, self.k_pop2[1], self.cloud2, self.cloud3, threshold))
        self.k_loss2.append(self.Overlap_ratio(-1, 2, self.k_pop2[2], self.cloud3, self.cloud1, threshold))
        self.save_best(best_ratio)

        for g in range(max_generations):
            t = time.time()
            n = 2 + 8 * (g / max_generations)
            # self.F = 0.5 + 0.5 * (g / max_generations)
            # transfer_prob1 = 0.5 + 0.5 * (g / max_generations)
            # k_mutant1: [[60, 6], [60, 6], [60, 6]]，保存的是fun1要使用的三个大矩阵
            # k_mutant2: [[60, 6], [60, 6], [60, 6]]，保存的是fun2要使用的三个大矩阵
            # if g < int(max_generations / 2):
            #     k_mutant1, k_mutant2 = self.mutate_rand1(transfer_prob1, transfer_prob2, best_ratio)
            # else:
            #     k_mutant1, k_mutant2 = self.mutate_best1(transfer_prob1, transfer_prob2, best_ratio)
            k_mutant1, k_mutant2 = self.mutate_best1(transfer_prob1, transfer_prob2, best_ratio)
            new_k_pop11, new_k_pop12, new_k_pop21, new_k_pop22 = self.SBX(k_mutant1, k_mutant2, n)
            new_k_pop11 = self.param_adjust(new_k_pop11)
            new_k_pop12 = self.param_adjust(new_k_pop12)
            new_k_pop21 = self.param_adjust(new_k_pop21)
            new_k_pop22 = self.param_adjust(new_k_pop22)
            new_k_losses11 = []
            new_k_losses12 = []
            new_k_losses21 = []
            new_k_losses22 = []
            new_k_losses11.append(self.MSE_threshold(new_k_pop11[0], self.cloud1, self.cloud2))
            new_k_losses11.append(self.MSE_threshold(new_k_pop11[1], self.cloud2, self.cloud3))
            new_k_losses11.append(self.MSE_threshold(new_k_pop11[2], self.cloud3, self.cloud1))
            new_k_losses12.append(self.MSE_threshold(new_k_pop12[0], self.cloud1, self.cloud2))
            new_k_losses12.append(self.MSE_threshold(new_k_pop12[1], self.cloud2, self.cloud3))
            new_k_losses12.append(self.MSE_threshold(new_k_pop12[2], self.cloud3, self.cloud1))
            new_k_losses21.append(self.Overlap_ratio(g, 0, new_k_pop21[0], self.cloud1, self.cloud2, threshold))
            new_k_losses21.append(self.Overlap_ratio(g, 1, new_k_pop21[1], self.cloud2, self.cloud3, threshold))
            new_k_losses21.append(self.Overlap_ratio(g, 2, new_k_pop21[2], self.cloud3, self.cloud1, threshold))
            new_k_losses22.append(self.Overlap_ratio(g, 0, new_k_pop22[0], self.cloud1, self.cloud2, threshold))
            new_k_losses22.append(self.Overlap_ratio(g, 1, new_k_pop22[1], self.cloud2, self.cloud3, threshold))
            new_k_losses22.append(self.Overlap_ratio(g, 2, new_k_pop22[2], self.cloud3, self.cloud1, threshold))
            # self.k_pop1, self.k_loss1 = self.select(1, self.k_pop1, self.k_loss1, new_k_pop11, new_k_losses11, new_k_pop12, new_k_losses12, best_ratio)
            # self.k_pop2, self.k_loss2 = self.select(2, self.k_pop2, self.k_loss2, new_k_pop21, new_k_losses21, new_k_pop22, new_k_losses22, best_ratio)
            self.k_pop1, self.k_loss1 = self.select2(1, self.k_pop1, self.k_loss1, new_k_pop11, new_k_losses11, new_k_pop12, new_k_losses12, best_ratio)
            self.k_pop2, self.k_loss2 = self.select2(2, self.k_pop2, self.k_loss2, new_k_pop21, new_k_losses21, new_k_pop22, new_k_losses22, best_ratio)
            print('generation %d: ' % (g + 1), time.time() - t, 's')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T1_f1_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses1[0], delimiter=',')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T2_f1_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses1[1], delimiter=',')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T3_f1_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses1[2], delimiter=',')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T1_f2_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses2[0], delimiter=',')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T2_f2_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses2[1], delimiter=',')
        # np.savetxt('./sharing_sensitivity/bun90180top2_T3_f2_share1_samp0.05_%d.txt'%(file_id), self.g_best_losses2[2], delimiter=',')
        # print('00000./o-40-41-42-0.005/I1_T3_f2_p1_0_p2_0_n2-10l_F0.5_b0.1_rand1_0_best1_1_alpha0.05_sbx1_s2_samp0.005_noise0_100_180_60_%d.txt'%(file_id))
        return self.k_best_individual1, self.k_best_loss1, self.k_best_individual2, self.k_best_loss2

# 这个用来测试官方提供了真实值的数据
if __name__ == '__main__':

    clouds_original = load_data()
    print(clouds_original[0])
    print(clouds_original[1])
    print(clouds_original[2])

    centers = []
    for i in range(3):
        centers.append(clouds_original[i].get_center())
        clouds_original[i].translate(- clouds_original[i].get_center())
    print(centers)

    mean_dis = []
    max_range = []
    for i in range(3):
        mean_dis.append(np.mean(np.asarray(clouds_original[i].compute_nearest_neighbor_distance())))
        max_range.append(np.max(np.max(np.asarray(clouds_original[i].points), axis=0) - np.min(np.asarray(clouds_original[i].points), axis=0)))

    threshold = np.mean(mean_dis) * np.sqrt(2) / 2
    shift = np.max(max_range)
    # print(threshold1)
    # print(shift)

    t = time.time()
    solution = Solution(100, clouds_original, [-180, 180], [-shift, shift], 0.5)
    trans1, loss1, trans2, loss2 = solution(60, threshold) # 60
    print(trans1)
    print(loss1)
    print(trans2)
    print(loss2)


    trans = SE3.SE3(trans2)
    pc1 = copy.deepcopy(clouds_original[0])
    pc2 = copy.deepcopy(clouds_original[1])
    pc3 = copy.deepcopy(clouds_original[2])
    pc2.transform(np.linalg.inv(trans[0]))
    pc3.transform(trans[2])
    pc1.paint_uniform_color([1, 0, 0])
    pc2.paint_uniform_color([0, 1, 0])
    pc3.paint_uniform_color([0, 0, 1])

    syn1 = np.dot(trans[2], np.dot(trans[1], trans[0]))
    syn1 = syn1 - np.eye(4)
    print('F norm of (T31*T23*T12 - I):', np.linalg.norm(syn1, ord='fro'))

    # 加载真实值计算误差
    # gt = np.load(r'D:\Datasets\Buste\buste_scandata\gtT_MA.npz')
    # t1 = gt['t_1002']
    # t2 = gt['t_1451']
    # t3 = gt['t_1452']
    # gt1 = np.dot(np.linalg.inv(t2), t1)
    # gt2 = np.dot(np.linalg.inv(t3), t2)
    # gt3 = np.dot(np.linalg.inv(t1), t3)
    t1 = np.eye(4)
    t2 = np.eye(4)
    t3 = np.eye(4)
    gt1 = np.dot(np.linalg.inv(t2), t1)
    gt2 = np.dot(np.linalg.inv(t3), t2)
    gt3 = np.dot(np.linalg.inv(t1), t3)

    # 把求出来的值变换成与真实值相同的形式
    temp1 = np.eye(4)
    temp1[0:3, 3] = - centers[0]
    temp3 = np.eye(4)
    temp3[0:3, 3] = centers[1]
    cal_t1 = np.dot(temp3, np.dot(trans[0], temp1))
    temp1 = np.eye(4)
    temp1[0:3, 3] = - centers[1]
    temp3 = np.eye(4)
    temp3[0:3, 3] = centers[2]
    cal_t2 = np.dot(temp3, np.dot(trans[1], temp1))
    temp1 = np.eye(4)
    temp1[0:3, 3] = - centers[2]
    temp3 = np.eye(4)
    temp3[0:3, 3] = centers[0]
    cal_t3 = np.dot(temp3, np.dot(trans[2], temp1))

    # 采用两两之间计算的方式
    fro_rotate1 = np.linalg.norm((cal_t1[0:3, 0:3] - gt1[0:3, 0:3]), ord='fro')
    fro_rotate2 = np.linalg.norm((cal_t2[0:3, 0:3] - gt2[0:3, 0:3]), ord='fro')
    fro_rotate3 = np.linalg.norm((cal_t3[0:3, 0:3] - gt3[0:3, 0:3]), ord='fro')
    fro_rotate_mean = (fro_rotate1 + fro_rotate2 + fro_rotate3) / 3
    fro_shift1 = np.linalg.norm(cal_t1[0:3, 3] - gt1[0:3, 3])
    fro_shift2 = np.linalg.norm(cal_t2[0:3, 3] - gt2[0:3, 3])
    fro_shift3 = np.linalg.norm(cal_t3[0:3, 3] - gt3[0:3, 3])
    fro_shift_mean = (fro_shift1 + fro_shift2 + fro_shift3) / 3
    print('**********calculate in pairwise manner**********')
    print('fro_rotate_mean: ', fro_rotate_mean)
    print('fro_shift_mean: ', fro_shift_mean)

    # 保持视角1不变，以多视角方式计算
    gt11 = np.eye(4)
    gt21 = np.linalg.inv(gt1)
    gt31 = gt3
    cal_t11 = np.eye(4)
    cal_t21 = np.linalg.inv(cal_t1)
    cal_t31 = cal_t3
    fro_rotate11 = np.linalg.norm((cal_t11[0:3, 0:3] - gt11[0:3, 0:3]), ord='fro')
    fro_rotate22 = np.linalg.norm((cal_t21[0:3, 0:3] - gt21[0:3, 0:3]), ord='fro')
    fro_rotate33 = np.linalg.norm((cal_t31[0:3, 0:3] - gt31[0:3, 0:3]), ord='fro')
    fro_rotate_mean2 = (fro_rotate11 + fro_rotate22 + fro_rotate33) / 3
    fro_shift11 = np.linalg.norm(cal_t11[0:3, 3] - gt11[0:3, 3])
    fro_shift22 = np.linalg.norm(cal_t21[0:3, 3] - gt21[0:3, 3])
    fro_shift33 = np.linalg.norm(cal_t31[0:3, 3] - gt31[0:3, 3])
    fro_shift_mean2 = (fro_shift11 + fro_shift22 + fro_shift33) / 3
    print('**********calculate in multiview manner**********')
    print('fro_rotate_mean: ', fro_rotate_mean2)
    print('fro_shift_mean: ', fro_shift_mean2)

    data = np.array([fro_rotate_mean, fro_shift_mean, fro_rotate_mean2, fro_shift_mean2])
    # np.savetxt('./sharing_sensitivity/bun90180top2_Error_share1_samp0.05_%d.txt'%(file_id), data, delimiter=',')
    print('total time:', time.time() - t, ' s')

    # # o3d.visualization.draw_geometries([ps11, pt11])
    # o3d.visualization.draw_geometries([ps1, pt1])
    # # o3d.visualization.draw_geometries([ps22, pt22])
    # o3d.visualization.draw_geometries([ps2, pt2])
    # # o3d.visualization.draw_geometries([ps33, pt33])
    # o3d.visualization.draw_geometries([ps3, pt3])
    o3d.visualization.draw_geometries([pc1, pc2, pc3])
