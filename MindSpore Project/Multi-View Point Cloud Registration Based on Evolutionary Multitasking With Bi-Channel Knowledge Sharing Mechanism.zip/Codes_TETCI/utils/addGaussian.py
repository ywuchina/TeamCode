import numpy as np
import open3d as o3d
from utils import LoadData
from utils import Sample
import copy

# 一次可以为多个点云添加高斯噪声，添加的高斯噪声独立于原来的点
def add_gaussian(clouds, noise_ratio):
    for i in range(len(clouds)):
        # 为一个点云添加高斯噪声
        points = np.asarray(clouds[i].points)
        # 三个维度上的均值[mean_x, mean_y, mean_z]
        mean = np.mean(points, axis=0)
        # 三个维度上的标准差[std_x, std_y, std_z]
        std = np.std(points, axis=0)
        # 计算要添加的高斯噪声点数
        noise_num = int(len(points) * noise_ratio)
        # 生成高斯噪声点
        noise = np.random.normal(mean, std, (noise_num, 3))
        # 把噪声点与原点云中的点进行拼接
        points = np.concatenate((points, noise), axis=0)
        clouds[i].points = o3d.utility.Vector3dVector(points)

# 直接在原始点上进行扰动添加高斯噪声
def add_gaussian2(clouds, deviation):
    for i in range(len(clouds)):
        center = clouds[i].get_center()
        clouds[i].translate(- center)
        points = np.asarray(clouds[i].points)
        max_points = np.max(points, axis=0)
        min_points = np.min(points, axis=0)
        min_points = np.abs(min_points)
        # print(min_points)
        max = np.max(np.concatenate((max_points, min_points)))
        # print(max)
        points /= max
        noise = np.random.normal(0, deviation, (len(points), 3))
        points += noise
        points *= max
        clouds[i].points = o3d.utility.Vector3dVector(points)
        clouds[i].translate(center)

if __name__ == '__main__':
    pc0  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_0.pcd')
    pc1  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_1.pcd')
    pc2  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_2.pcd')
    pc3  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_10.pcd')
    pc4  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_11.pcd')
    pc5  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_12.pcd')
    pc6  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_16.pcd')
    pc7  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_17.pcd')
    pc8  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_18.pcd')
    pc9  = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_40.pcd')
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_41.pcd')
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005\cloud_bin_42.pcd')
    # pc12 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1\buste_2451.pcd')
    # pc13 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1\buste_2452.pcd')
    # pc14 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1\buste_2453.pcd')
    # pc15 = o3d.io.read_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1\buste_2454.pcd')
    pc = [pc0, pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11]
    add_gaussian2(pc, 0.03)
    # new_bun0 = Sample.farthest_down_sample(bunny[0], 0.1)
    # new_bun1 = Sample.farthest_down_sample(bunny[1], 0.1)
    # new_bun2 = Sample.farthest_down_sample(bunny[2], 0.1)
    o3d.visualization.draw_geometries(pc)
    # o3d.visualization.draw_geometries([bunny[0], bunny[1], bunny[2]])
    # bunny = [pc0, pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9]
    # gt = np.load(r'D:\Datasets\bunny\data\gtT.npz')
    # t0 = gt['t_000']
    # t1 = gt['t_045']
    # t2 = gt['t_090']
    # t3 = gt['t_180']
    # t4 = gt['t_270']
    # t5 = gt['t_315']
    # t6 = gt['t_chin']
    # t7 = gt['t_ear']
    # t8 = gt['t_top2']
    # t9 = gt['t_top3']
    # t = [t0, t1, t2, t3, t4, t5, t6, t7, t8, t9]
    # for i in range(10):
    #     bunny[i].transform(t[i])
    # o3d.visualization.draw_geometries(bunny)
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_0.pcd', pc[0])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_1.pcd', pc[1])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_2.pcd', pc[2])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_10.pcd', pc[3])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_11.pcd', pc[4])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_12.pcd', pc[5])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_16.pcd', pc[6])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_17.pcd', pc[7])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_18.pcd', pc[8])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_40.pcd', pc[9])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_41.pcd', pc[10])
    o3d.io.write_point_cloud(r'D:\Datasets\experiments\office2\office2_aligned_0.005_0.03\cloud_bin_42.pcd', pc[11])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1_0.03\buste_2451.pcd', pc[12])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1_0.03\buste_2452.pcd', pc[13])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1_0.03\buste_2453.pcd', pc[14])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buste\buste_aligned_0.1_0.03\buste_2454.pcd', pc[15])






