import numpy as np
import open3d as o3d
import copy
from utils import SE3
from utils import SO3

# 产生随机扰动
def generate_perturbation():
    bun = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_res3.pcd")
    # bun2 = copy.deepcopy(bun)
    # bun2.paint_uniform_color(np.random.random(3))
    # bun2.translate([0.1, 0, 0])
    # o3d.visualization.draw_geometries([bun, bun2])
    rotations = ((-1 + np.random.random((3, 3)) * 2) * 90)
    shifts = (-1 + np.random.random((3, 3)) * 2) * 0.05
    transformations = np.concatenate((rotations, shifts), axis=1)
    matrices = SE3.SE3(transformations)
    print(rotations)
    print(shifts)
    np.savetxt("./pertubations.txt", transformations, delimiter=',')
    for i in range(3):
        bun_copy = copy.deepcopy(bun)
        # bun_copy.rotate(SO3.SO3_single(rotations[i]), center=(0, 0, 0))
        # bun_copy.translate(shifts[i])
        bun_copy.transform(matrices[i])
        o3d.io.write_point_cloud("D:/Datasets/bunny/data_pcd/bun_{}.pcd".format(i+1), bun_copy)


if __name__ == '__main__':
    generate_perturbation()
    bun = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_res3.pcd")
    bun1 = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_1.pcd")
    bun2 = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_2.pcd")
    bun3 = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_3.pcd")
    bun.paint_uniform_color([0.5, 0.5, 0.5])
    bun1.paint_uniform_color([1, 0, 0])
    bun2.paint_uniform_color([0, 1, 0])
    bun3.paint_uniform_color([0, 0, 1])

    o3d.visualization.draw_geometries([bun, bun1, bun2, bun3])
    # bun = o3d.io.read_point_cloud("D:/Datasets/bunny/data_pcd/bun_res3.pcd")
    # bun.paint_uniform_color([1, 0, 0])
    # bun_copy1 = copy.deepcopy(bun)
    # bun_copy2 = copy.deepcopy(bun)
    # rotations = ((-1 + np.random.random(3) * 2) * 90)
    # shifts = (-1 + np.random.random(3) * 2) * 0.05
    # bun_copy1.rotate(SO3.SO3_single(rotations), center=(0, 0, 0))
    # bun_copy1.translate(shifts)
    # bun_copy1.paint_uniform_color([0, 1, 0])
    # bun_copy2.transform(SE3.SE3_single(np.concatenate((rotations, shifts))))
    # bun_copy2.paint_uniform_color([0, 0, 1])
    # o3d.visualization.draw_geometries([bun, bun_copy2, bun_copy1])
