import numpy as np
from utils import SO3
import math

# 从单个6维向量变成4*4变换矩阵
def SE3_single(transformation):
    rotation = SO3.SO3_single(transformation[0:3])
    T = np.identity(4)
    T[0:3, 0:3] = rotation
    T[0:3, 3] = transformation[3:]
    return T

# N * 6的N个向量变换为N个变换矩阵
def SE3(transformations):
    Ts = np.zeros(shape=(len(transformations), 4, 4))
    for i in range(len(transformations)):
        Ts[i] = SE3_single(transformations[i])
    return Ts

# 由旋转矩阵得到欧拉角
def rotationMatrixToEulerAngles(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6
    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0
    return np.degrees([x, y, z])

# 由变换矩阵得到6维向量
def transformationMatrixToVectors(T):
    angles = rotationMatrixToEulerAngles(T[0:3, 0:3])
    shifts = T[0:3, 3]
    return np.array(angles.tolist() + shifts.tolist())

def f_norm(T1, T2, T3):
    return np.linalg.norm((np.dot(T1, T2) - np.linalg.inv(T3)), ord='fro')

def f_normI(T1, T2, T3):
    return np.linalg.norm((np.dot(T1, np.dot(T2, T3)) - np.eye(4)), ord='fro')

if __name__ == '__main__':
    p1 = [20, 5, -15, 0, 0, 0]
    p2 = [50, -10, -10, 0, 0, 0]
    p3 = [5, -10, 56, 0, 0, 0]
    T1 = SE3_single(p1)
    T2 = SE3_single(p2)
    print(rotationMatrixToEulerAngles(T1))
    print(rotationMatrixToEulerAngles(T2))
    # T3 = np.dot(np.linalg.inv(T1), np.linalg.inv(T2))
    T3 = SE3_single(p3)
    print(np.dot(T3, np.dot(T2, T1)))
    print(f_norm(T3, T2, T1))
    print(f_norm(T1, T3, T2))
    print(f_norm(T2, T1, T3))
    print(f_normI(T3, T2, T1))