import numpy as np
import copy

# 没用了
def select1(self, pop, loss, new_pop, new_loss):
    for i in range(len(pop)):
        if new_loss[i] <= loss[i]:
            loss[i] = new_loss[i]
            pop[i] = copy.deepcopy(new_pop[i])
            # for j in range(6):
            #     pop[i, j] = new_pop[i, j]
    if np.min(loss) < np.min(new_loss):
        self.best_individual = pop[np.argmin(loss)]
        self.best_losses.append(np.min(loss))
    else:
        self.best_individual = new_pop[np.argmin(new_loss)]
        self.best_losses.append(np.min(new_loss))
    return pop, loss


def select2(self, pop, loss, new_pop, new_loss):
    doublepop = np.concatenate((pop, new_pop), axis=0)
    doubleloss = np.concatenate((loss, new_loss), axis=0)
    self.best_individual = doublepop[np.argmin(doubleloss)]
    self.best_losses.append(np.min(doubleloss))
    return doublepop[np.argsort(doubleloss)[:len(pop)]], doubleloss[np.argsort(doubleloss)[:len(pop)]]