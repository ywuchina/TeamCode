import glob
import numpy as np
import matplotlib.pyplot as plt

# 用于画图，把main函数里的路径改掉就行了
def get_losses(path):
    names = glob.glob(path)
    print(len(names))
    losses = np.zeros(61)
    for name in names:
        data = np.loadtxt(name, delimiter=',')
        losses += data
    losses = losses / len(names)
    return losses

def get_loss(path):
    data = np.loadtxt(path)
    return [data[2], data[3]]

def draw_losses(loss1, loss2, loss3, loss4, loss5, loss6, T, f):
    num_losses = len(loss1)
    plt.plot(np.arange(num_losses), loss1, 'r>-', label='MTPCR')
    plt.plot(np.arange(num_losses), loss2, 'b.-', label='MTPCR-Intra')
    plt.plot(np.arange(num_losses), loss3, 'g+-', label='MTPCR-Inter')
    plt.plot(np.arange(num_losses), loss4, 'y2-', label='MTPCR-NKS')
    plt.plot(np.arange(num_losses), loss5, 'mP-', label='MFEA')
    plt.plot(np.arange(num_losses), loss6, c='orange', marker='*', label='GMFEA')
    plt.legend()
    plt.tick_params(labelsize=12)
    plt.xlabel('Generation', fontsize=14)
    plt.ylabel('Average loss', fontsize=14)
    title = 'Buddha-c: J3-o'
    plt.title(title, fontsize=16)
    # plt.show()
    plt.savefig(r'C:\Users\NN\Desktop\convergence\budc3o.png', dpi=300)

# 用于同一个任务的不同alpha参数画图
def draw_losses2(loss1, loss2, loss3, loss4, loss5, loss6, T, f):
    num_losses = len(loss1)
    plt.plot(np.arange(num_losses), loss1, 'r.-', label='α: 0.5')
    plt.plot(np.arange(num_losses), loss2, 'b.-', label='α: 0.2')
    plt.plot(np.arange(num_losses), loss3, 'g.-', label='α: 0.1')
    plt.plot(np.arange(num_losses), loss4, 'y.-', label='α: 0.05')
    plt.plot(np.arange(num_losses), loss5, 'm.-', label='α: 0.02')
    plt.plot(np.arange(num_losses), loss6, c='orange', marker='.', label='α: 0.01')
    plt.legend()
    plt.tick_params(labelsize=12)
    plt.xlabel('Generation', fontsize=14)
    plt.ylabel('Average loss', fontsize=14)
    title = 'Bunny-c: J3-o'
    plt.title(title, fontsize=16)
    # plt.show()
    plt.savefig(r'D:\ShareFolder\Paper\Alpha\bunc3o.png', dpi=300)

def draw_losses_diffratio(losses1_r, losses1_t, losses2_r, losses2_t, losses3_r, losses3_t):
    x = [0.01, 0.02, 0.03, 0.04, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5]
    plt.plot(x, losses1_t, 'r.-', label='Bunny-a')
    plt.plot(x, losses2_t, 'g.-', label='Bunny-b')
    plt.plot(x, losses3_t, 'b.-', label='Bunny-c')
    plt.legend()
    plt.tick_params(labelsize=12)
    plt.xlabel('Sample ratio', fontsize=14)
    plt.ylabel('Translation error', fontsize=14)
    title = 'Sensitivity of sample ratio'
    plt.title(title, fontsize=16)
    # plt.show()
    plt.savefig(r'D:\ShareFolder\Paper\Alpha\sampleT.png', dpi=300, bbox_inches='tight')

def draw_losses_sharing(loss1, loss2, loss3, loss4, loss5, loss6, loss7, T, f):
    num_losses = len(loss1)
    plt.plot(np.arange(num_losses), loss1, 'r.-', label='prob: 0.0')
    plt.plot(np.arange(num_losses), loss2, 'b.-', label='prob: 0.2')
    plt.plot(np.arange(num_losses), loss3, 'g.-', label='prob: 0.4')
    plt.plot(np.arange(num_losses), loss4, 'y.-', label='prob: 0.5')
    plt.plot(np.arange(num_losses), loss5, 'm.-', label='prob: 0.6')
    plt.plot(np.arange(num_losses), loss6, c='orange', marker='.', label='prob: 0.8')
    plt.plot(np.arange(num_losses), loss7, marker='.', label='prob: 1.0')
    plt.legend()
    plt.tick_params(labelsize=12)
    plt.xlabel('Generation', fontsize=14)
    plt.ylabel('Average loss', fontsize=14)
    title = 'Bunny-c: J3-o'
    plt.title(title, fontsize=16)
    # plt.show()
    plt.savefig(r'D:\ShareFolder\Paper\Transfer\bunnyc3o.png', dpi=300)

str = r'..\sharing_sensitivity'

if __name__ == '__main__':

    T = 3
    f = 2
    loss1 = get_losses(str + r'\bun90180top2_T%d_f%d_share0_samp0.05_*.txt'%(T, f))
    loss2 = get_losses(str + r'\bun90180top2_T%d_f%d_share0.2_samp0.05_*.txt'%(T, f))
    loss3 = get_losses(str + r'\bun90180top2_T%d_f%d_share0.4_samp0.05_*.txt'%(T, f))
    loss4 = get_losses(str + r'\bun90180top2_T%d_f%d_share0.5_samp0.05_*.txt'%(T, f))
    loss5 = get_losses(str + r'\bun90180top2_T%d_f%d_share0.6_samp0.05_*.txt'%(T, f))
    loss6 = get_losses(str + r'\bun90180top2_T%d_f%d_share0.8_samp0.05_*.txt'%(T, f))
    loss7 = get_losses(str + r'\bun90180top2_T%d_f%d_share1_samp0.05_*.txt'%(T, f))
    draw_losses_sharing(loss1, loss2, loss3, loss4, loss5, loss6, loss7, T, f)

    # 针对不同采样率的图像
    # loss1_1 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.01_1.txt')
    # loss1_2 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.02_1.txt')
    # loss1_3 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.03_1.txt')
    # loss1_4 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.04_1.txt')
    # loss1_5 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.05_1.txt')
    # loss1_6 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.1_1.txt')
    # loss1_7 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.2_1.txt')
    # loss1_8 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.3_1.txt')
    # loss1_9 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.4_1.txt')
    # loss1_10 = get_loss(r'..\sample_ratio_sensitivity\bun0045315_Error_alpha0.05_samp0.5_1.txt')
    # losses1_r = [loss1_1[0], loss1_2[0], loss1_3[0], loss1_4[0], loss1_5[0], loss1_6[0], loss1_7[0], loss1_8[0], loss1_9[0], loss1_10[0]]
    # losses1_t = [loss1_1[1], loss1_2[1], loss1_3[1], loss1_4[1], loss1_5[1], loss1_6[1], loss1_7[1], loss1_8[1], loss1_9[1], loss1_10[1]]
    # loss2_1 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.01_1.txt')
    # loss2_2 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.02_1.txt')
    # loss2_3 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.03_1.txt')
    # loss2_4 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.04_1.txt')
    # loss2_5 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.05_1.txt')
    # loss2_6 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.1_1.txt')
    # loss2_7 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.2_1.txt')
    # loss2_8 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.3_1.txt')
    # loss2_9 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.4_1.txt')
    # loss2_10 = get_loss(r'..\sample_ratio_sensitivity\bun0090top3_Error_alpha0.05_samp0.5_1.txt')
    # losses2_r = [loss2_1[0], loss2_2[0], loss2_3[0], loss2_4[0], loss2_5[0], loss2_6[0], loss2_7[0], loss2_8[0],
    #              loss2_9[0], loss2_10[0]]
    # losses2_t = [loss2_1[1], loss2_2[1], loss2_3[1], loss2_4[1], loss2_5[1], loss2_6[1], loss2_7[1], loss2_8[1],
    #              loss2_9[1], loss2_10[1]]
    # loss3_1 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.01_1.txt')
    # loss3_2 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.02_1.txt')
    # loss3_3 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.03_1.txt')
    # loss3_4 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.04_1.txt')
    # loss3_5 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.05_1.txt')
    # loss3_6 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.1_1.txt')
    # loss3_7 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.2_1.txt')
    # loss3_8 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.3_1.txt')
    # loss3_9 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.4_1.txt')
    # loss3_10 = get_loss(r'..\sample_ratio_sensitivity\bun90180top2_Error_alpha0.05_samp0.5_1.txt')
    # losses3_r = [loss3_1[0], loss3_2[0], loss3_3[0], loss3_4[0], loss3_5[0], loss3_6[0], loss3_7[0], loss3_8[0],
    #              loss3_9[0], loss3_10[0]]
    # losses3_t = [loss3_1[1], loss3_2[1], loss3_3[1], loss3_4[1], loss3_5[1], loss3_6[1], loss3_7[1], loss3_8[1],
    #              loss3_9[1], loss3_10[1]]
    # draw_losses_diffratio(losses1_r, losses1_t, losses2_r, losses2_t, losses3_r, losses3_t)
