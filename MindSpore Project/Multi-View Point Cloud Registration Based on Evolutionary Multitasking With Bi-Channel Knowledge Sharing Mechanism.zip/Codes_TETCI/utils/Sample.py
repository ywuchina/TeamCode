import numpy as np
import open3d as o3d
from utils import SO3
from utils.SE3 import SE3_single
import copy
from utils import LoadData

# 都是最远点采样，最后一种没用了，第一种是指定一个采样比例，第二种直接指定要采样的点数
def farthest_down_sample(cloud, ratio):
    points = np.asarray(cloud.points)
    N = points.shape[0]
    npoint = int(N * ratio)
    distances = np.full((N,), float('inf'))
    centroids = np.empty((npoint,), dtype=int)
    # farthest = np.random.randint(0, N)
    farthest = 0
    for i in range(npoint):
        centroids[i] = farthest
        centroid = points[farthest]
        dist = np.sum((points - centroid) ** 2, axis=1)
        mask = dist < distances
        distances[mask] = dist[mask]
        farthest = np.argmax(distances)
    new_points = points[centroids]
    new_cloud = o3d.geometry.PointCloud()
    new_cloud.points = o3d.utility.Vector3dVector(new_points)
    return new_cloud

def farthest_down_sample_k(cloud, k):
    points = np.asarray(cloud.points)
    N = points.shape[0]
    npoint = k
    distances = np.full((N,), float('inf'))
    centroids = np.empty((npoint,), dtype=int)
    # 从随机采样变为固定取第一个点
    # farthest = np.random.randint(0, N)
    farthest = 0
    for i in range(npoint):
        centroids[i] = farthest
        centroid = points[farthest]
        dist = np.sum((points - centroid) ** 2, axis=1)
        mask = dist < distances
        distances[mask] = dist[mask]
        farthest = np.argmax(distances)
    new_points = points[centroids]
    new_cloud = o3d.geometry.PointCloud()
    new_cloud.points = o3d.utility.Vector3dVector(new_points)
    return new_cloud

def farthest_down_sample_n(cloud, ratio, distance, cloud_num):
    points = np.asarray(cloud.points)
    N = points.shape[0]
    npoint = int(N * ratio)
    distances = np.full((N,), float('inf'))
    centroids = np.empty((npoint,), dtype=int)
    farthest = np.random.randint(0, N)
    for i in range(npoint):
        centroids[i] = farthest
        centroid = points[farthest]
        dist = np.sum((points - centroid) ** 2, axis=1)
        mask = dist < distances
        distances[mask] = dist[mask]
        farthest = np.argmax(distances)
    new_points = points[centroids]
    start_ratio = 1.0 / cloud_num
    min_dis = float('inf')
    new_cloud = None
    for r in np.arange(start_ratio, (cloud_num - 0.4 * (cloud_num - 1)) / cloud_num + 1e-6, 0.1):
        cloud_i = o3d.geometry.PointCloud()
        cloud_i.points = o3d.utility.Vector3dVector(new_points[:int(r * npoint)])
        dis = cloud_i.compute_nearest_neighbor_distance()
        mean_dis = np.mean(dis)
        if(np.abs(distance - mean_dis) < min_dis):
            min_dis = np.abs(distance - mean_dis)
            new_cloud = cloud_i
    return new_cloud

def normalize(cloud):
    center = cloud.get_center()
    cloud.translate(- center)
    points = np.asarray(cloud.points)
    max_points = np.max(points, axis=0)
    min_points = np.min(points, axis=0)
    min_points = np.abs(min_points)
    max = np.max(np.concatenate((max_points, min_points)))
    # points /= (max * 1.2)
    points /= max

if __name__ == '__main__':

    clouds = LoadData.load_buddha_side()

    clouds_samp_0 = farthest_down_sample_k(clouds[0], 2048)
    clouds_samp_1 = farthest_down_sample_k(clouds[1], 2048)
    clouds_samp_2 = farthest_down_sample_k(clouds[2], 2048)
    clouds_samp_3 = farthest_down_sample_k(clouds[3], 2048)
    clouds_samp_4 = farthest_down_sample_k(clouds[4], 2048)
    clouds_samp_5 = farthest_down_sample_k(clouds[5], 2048)
    clouds_samp_6 = farthest_down_sample_k(clouds[6], 2048)
    clouds_samp_7 = farthest_down_sample_k(clouds[7], 2048)
    clouds_samp_8 = farthest_down_sample_k(clouds[8], 2048)
    clouds_samp_9 = farthest_down_sample_k(clouds[9], 2048)
    clouds_samp_10 = farthest_down_sample_k(clouds[10], 2048)
    clouds_samp_11 = farthest_down_sample_k(clouds[11], 2048)
    clouds_samp_12 = farthest_down_sample_k(clouds[12], 2048)
    clouds_samp_13 = farthest_down_sample_k(clouds[13], 2048)
    clouds_samp_14 = farthest_down_sample_k(clouds[14], 2048)

    normalize(clouds_samp_0)
    normalize(clouds_samp_1)
    normalize(clouds_samp_2)
    normalize(clouds_samp_3)
    normalize(clouds_samp_4)
    normalize(clouds_samp_5)
    normalize(clouds_samp_6)
    normalize(clouds_samp_7)
    normalize(clouds_samp_8)
    normalize(clouds_samp_9)
    normalize(clouds_samp_10)
    normalize(clouds_samp_11)
    normalize(clouds_samp_12)
    normalize(clouds_samp_13)
    normalize(clouds_samp_14)

    o3d.visualization.draw_geometries([clouds_samp_0, clouds_samp_1, clouds_samp_2, clouds_samp_3, clouds_samp_4,
                                       clouds_samp_5, clouds_samp_6, clouds_samp_7, clouds_samp_8, clouds_samp_9,
                                       clouds_samp_10, clouds_samp_11, clouds_samp_12, clouds_samp_13, clouds_samp_14
                                       ])
    
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_0.pcd', clouds_samp_0)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_1.pcd', clouds_samp_1)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_2.pcd', clouds_samp_2)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_3.pcd', clouds_samp_3)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_4.pcd', clouds_samp_4)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_5.pcd', clouds_samp_5)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_6.pcd', clouds_samp_6)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_7.pcd', clouds_samp_7)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_8.pcd', clouds_samp_8)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_9.pcd', clouds_samp_9)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_10.pcd', clouds_samp_10)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_11.pcd', clouds_samp_11)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_12.pcd', clouds_samp_12)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_13.pcd', clouds_samp_13)
    o3d.io.write_point_cloud(r'D:\Datasets\autoencoderdata\normalized\buddha_side\buddha_side_14.pcd', clouds_samp_14)








