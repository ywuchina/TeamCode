import numpy as np
import matplotlib.pyplot as plt

def draw_transfer_char(path, title):
    data = np.loadtxt(path)
    plt.scatter(np.arange(len(data)), data)
    plt.title(title)
    plt.show()

if __name__ == "__main__":
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter1a.txt', "inter-1-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter2a.txt', "inter-2-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter3a.txt', "inter-3-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra1a.txt', "intra-1-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra2a.txt', "intra-2-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra3a.txt', "intra-3-a, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter1o.txt', "inter-1-o, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter2o.txt', "inter-2-o, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_inter3o.txt', "inter-3-o, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra1o.txt', "intra-1-o, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra2o.txt', "intra-2-o, 0.5,0.5,0.2")
    draw_transfer_char('../transferValidity/bun0045315-0.50.50.2/elite_intra3o.txt', "intra-3-o, 0.5,0.5,0.2")