import numpy as np
import copy
from utils import SO3
import open3d as o3d

# 没什么用了
def MSE_measure(pop, ps, pt, save_best=False):
    losses = []
    rot_matrices = SO3.SO3(pop[:, 0:3])
    shift_vectors = pop[:, 3:]
    for i in range(len(pop)):
        ps_copy = copy.deepcopy(ps)
        ps_copy.rotate(rot_matrices[i], center=(0, 0, 0))
        ps_copy.translate(shift_vectors[i])
        distances = ps_copy.compute_point_cloud_distance(pt)
        losses.append(np.sum(distances) / len(np.asarray(ps.points)))
    if save_best:
        best_individual = pop[np.argmin(np.array(losses))]
        return np.array(losses), best_individual
    else:
        return np.array(losses)

def MSE_threshold(pop, ps, pt, value=0.005, save_best=False):
    losses = []
    rot_matrices = SO3.SO3(pop[:, 0:3])
    shift_vectors = pop[:, 3:]
    ps_num_points = len(np.asarray(ps.points))
    for i in range(len(pop)):
        ps_copy = copy.deepcopy(ps)
        ps_copy.rotate(rot_matrices[i], center=(0, 0, 0))
        ps_copy.translate(shift_vectors[i])
        distances = ps_copy.compute_point_cloud_distance(pt)
        distances = np.asarray(distances)
        distances[distances > value] = value
        loss = np.sum(distances) / ps_num_points
        losses.append(loss)
    if save_best:
        best_individual = pop[np.argmin(np.array(losses))]
        return np.array(losses), best_individual
    else:
        return np.array(losses)

def Overlap_ratio(pop, ps, pt, value, save_best=False):
    losses = []
    rot_matrices = SO3.SO3(pop[:, 0:3])
    shift_vectors = pop[:, 3:]
    ps_num_points = len(np.asarray(ps.points))
    for i in range(len(pop)):
        ps_copy = copy.deepcopy(ps)
        ps_copy.rotate(rot_matrices[i], center=(0, 0, 0))
        ps_copy.translate(shift_vectors[i])
        distances = np.asarray(ps_copy.compute_point_cloud_distance(pt))
        num_correct = np.sum(distances < value)
        correct_ratio = num_correct / ps_num_points
        loss = 1 - correct_ratio
        losses.append(loss)
    if save_best:
        best_individual = pop[np.argmin(np.array(losses))]
        return np.array(losses), best_individual
    else:
        return np.array(losses)

def SIM_measure(pop, ps, pt, nn_num=50, save_best=False):
    losses = []
    tree_pt = o3d.geometry.KDTreeFlann(pt)
    rot_matrices = SO3.SO3(pop[:, 0:3])
    shift_vectors = pop[:, 3:]
    for i in range(len(pop)):
        ps_copy = copy.deepcopy(ps)
        ps_copy.rotate(rot_matrices[i], center=(0, 0, 0))
        ps_copy.translate(shift_vectors[i])
        tree_ps = o3d.geometry.KDTreeFlann(ps_copy)
        sim_num = 0
        points_num = len(ps_copy.points)
        for j in range(points_num):
            dot_results = np.zeros(nn_num)
            _, c_id, _ = tree_pt.search_knn_vector_3d(ps_copy.points[j], 1)
            _, n_ids, _ = tree_ps.search_knn_vector_3d(ps_copy.points[j], nn_num+1)
            c_id = np.asarray(c_id)
            n_ids = np.asarray(n_ids)
            c_xyz = np.asarray(pt.points)[c_id].squeeze()
            c_normal = np.asarray(pt.normals)[c_id].squeeze()
            n_ids = n_ids[1:]
            for k in range(nn_num):
                dot_results[k] = np.dot((ps_copy.points[n_ids[k]]-c_xyz), c_normal)
            if np.sum(dot_results>0) > 0 and np.sum(dot_results < 0) > 0:
                sim_num += 1
        sim_val = sim_num / points_num
        loss = 1 - sim_val
        losses.append(loss)
    if save_best:
        best_individual = pop[np.argmin(np.array(losses))]
        return np.array(losses), best_individual
    else:
        return np.array(losses)