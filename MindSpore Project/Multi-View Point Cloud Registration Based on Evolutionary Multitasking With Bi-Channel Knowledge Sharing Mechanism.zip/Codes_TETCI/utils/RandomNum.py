import numpy as np
import random

def generate_exclusive_numbers(num_rows, num_cols):
    # 生成num_rows行，num_cols列的数组，数字范围为[0, num_rows-1]，每一行数字不重复且不包含与当前行号相同的数字
    # 至于为什么不包含与当前行号相同的数字，是为了与“Qin et al. 2009”论文中对mutation vector的描述一致
    exclusive_numbers = []
    for i in range(num_rows):
        l = list(range(0, num_rows))
        l.remove(i)
        numbers_rowi = random.sample(l, num_cols)
        exclusive_numbers.append(numbers_rowi)
    return np.array(exclusive_numbers)

if __name__ == '__main__':
    randoms = generate_exclusive_numbers(10, 9)
    print(randoms)