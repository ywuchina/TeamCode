import numpy as np
import copy
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import open3d as o3d
from utils import SO3
from utils import SE3

# 比较早时候写的函数，可以展示种群在三维空间动态搜索的过程，比较久没用了，有些细节估计得更改
# 需要电脑上安装imagemagic
def draw_populations(pop_all_gens, range_angles, real_angle, save_path):
    fig = plt.figure()
    ax = Axes3D(fig)
    len_angles = range_angles[1] - range_angles[0]
    if len_angles % 20 == 0:
        num = len_angles // 20 + 1
    elif len_angles % 10 == 0:
        num = len_angles // 10 + 1
    else:
        num = 11
    def update(data):
        ax.cla()
        ax.set_xlim3d(range_angles)
        ax.set_xticks(np.linspace(range_angles[0], range_angles[1], num))
        ax.set_xlabel('X axis')
        ax.set_ylim3d(range_angles)
        ax.set_yticks(np.linspace(range_angles[0], range_angles[1], num))
        ax.set_ylabel('Y axis')
        ax.set_zlim3d(range_angles)
        ax.set_zticks(np.linspace(range_angles[0], range_angles[1], num))
        ax.set_zlabel('Z axis')
        ax.scatter(real_angle[0], real_angle[1], real_angle[2], c='red', marker='^')
        ax.scatter(data[:, 0], data[:, 1], data[:, 2])
    ani = FuncAnimation(fig, update, pop_all_gens, interval=400, blit=False)
    ani.save(save_path, writer='imagemagick', fps=120)
    plt.show()

def draw_losses(losses, manual_loss=None, title='Losses'):
    fig, ax = plt.subplots()
    num_losses = len(losses)
    ax.plot(np.arange(num_losses), losses)
    if manual_loss is not None:
        ax.plot(np.arange(num_losses), np.full(num_losses, manual_loss), c='r')
    ax.annotate(round(losses[0], 5), xy=(0, losses[0]))
    ax.annotate(round(losses[num_losses//2], 5), xy=(num_losses//2, losses[num_losses//2]))
    ax.annotate(round(losses[num_losses-1], 5), xy=(num_losses-1, losses[num_losses-1]))
    ax.set_title(title)
    plt.show()

def draw_geometries(ps, pt, transformation):
    ps_copy = copy.deepcopy(ps)
    pt_copy = copy.deepcopy(pt)
    matrix = SE3.SE3_single(transformation)
    ps_copy.transform(matrix)
    ps_copy.paint_uniform_color([1, 0, 0])
    pt_copy.paint_uniform_color([0, 1, 0])
    o3d.visualization.draw_geometries([ps_copy, pt_copy])