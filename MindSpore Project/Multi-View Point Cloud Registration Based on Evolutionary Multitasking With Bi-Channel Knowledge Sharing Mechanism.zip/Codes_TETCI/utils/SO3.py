import numpy as np
import math

# 把单个旋转角转换为旋转矩阵
def SO3_single(angles_single):    #angles_single: shape(3,)
    x_angle, y_angle, z_angle = angles_single
    sin_x = math.sin(math.radians(x_angle)) # math.radians(x) 角度转弧度
    cos_x = math.cos(math.radians(x_angle))
    sin_y = math.sin(math.radians(y_angle))
    cos_y = math.cos(math.radians(y_angle))
    sin_z = math.sin(math.radians(z_angle))
    cos_z = math.cos(math.radians(z_angle))
    # 根据三个旋转角度到旋转矩阵的变换公式计算
    # 这种表示方式是逆着x轴看过去，旋转是逆时针的
    arr1 = np.array([[1, 0, 0], [0, cos_x, -sin_x], [0, sin_x, cos_x]])
    arr2 = np.array([[cos_y, 0, sin_y], [0, 1, 0], [-sin_y, 0, cos_y]])
    arr3 = np.array([[cos_z, -sin_z, 0], [sin_z, cos_z, 0], [0, 0, 1]])
    R = np.dot(arr3, np.dot(arr2, arr1))    # 分别沿x y z轴进行旋转
    # R = np.dot(arr1, np.dot(arr2, arr3))
    return R

# 把打包的旋转角转换为旋转矩阵
def SO3(angles):    # angles: shape(n, 3)
    rot_matrices = np.zeros(shape=(angles.shape[0], 3, 3))
    for i in range(angles.shape[0]):
        rot_matrices[i] = SO3_single(angles[i])
    return rot_matrices

def rotationMatrixToEulerAngles(R):
    sy = math.sqrt(R[0, 0] * R[0, 0] + R[1, 0] * R[1, 0])
    singular = sy < 1e-6
    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0
    return np.degrees([x, y, z])
    # return np.array([x, y, z])

if __name__ == '__main__':
    R = SO3_single([1, 2, 3])
    print(R)
    R2 = SO3_single([-8.117, 65.44, -122.67])
    print(R2)
    print(rotationMatrixToEulerAngles(R))
    print(rotationMatrixToEulerAngles(R2))
    # print(np.linalg.norm(R - R2, ord='fro'))
    # angle = rotationMatrixToEulerAngles(R)
    # print(angle)