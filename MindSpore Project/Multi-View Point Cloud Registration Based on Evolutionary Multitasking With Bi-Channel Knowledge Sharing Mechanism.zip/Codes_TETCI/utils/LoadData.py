import open3d as o3d
from utils import Draw
import numpy as np
from utils import SO3
from utils import SE3
from utils import Sample

def paint_color(pc):
    colors = np.array([
        [1, 1, 0], [1, 0, 1], [0, 1, 1], [1, 0, 0], [0, 1, 0], [0, 0, 1],
        [0.6, 0.5, 0.4], [0.5, 0.7, 0.3], [0.7, 0.3, 0.5],
        [0.4, 0.5, 0.6], [0.5, 0.3, 0.7], [0.3, 0.5, 0.7],
        [0.3, 0.7, 0.5], [0.7, 0.5, 0.3], [0.5, 0.4, 0.6],
        [0.6, 0.5, 0.4], [0.5, 0.7, 0.3], [0.7, 0.3, 0.5],
        [0.4, 0.5, 0.6], [0.5, 0.3, 0.7], [0.3, 0.5, 0.7],
        [0.3, 0.7, 0.5], [0.7, 0.5, 0.3], [0.5, 0.4, 0.6]
    ])
    for i in range(len(pc)):
        pc[i].paint_uniform_color(colors[i % 24])

# pcd版本是已经去除了离群点的
def load_armadillo_stand():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_0.pcd')    #28220
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_30.pcd')   #27315
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_60.pcd')   #24029
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_90.pcd')   #20960
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_120.pcd')  #26641
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_150.pcd')  #28476
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_180.pcd')  #26941
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_210.pcd')  #25570
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_240.pcd')  #19232
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_270.pcd') #24034
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_300.pcd') #27792
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloStand\ArmadilloStand_330.pcd') #28415
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12]
    # paint_color(pc)
    return pc

# pcd版本是已经去除了离群点的
def load_armadillo_back():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_0.pcd')     #19276
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_30.pcd')    #12134
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_60.pcd')    #20748
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_90.pcd')    #24206
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_120.pcd')   #27136
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_150.pcd')   #27060
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_180.pcd')   #20524
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_210.pcd')   #18513
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_240.pcd')   #18682
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_270.pcd')   #25636
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_300.pcd')   #29851
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloBack\ArmadilloBack_330.pcd')   #29104
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12]
    return pc

def load_armadillo_on_head():   # 不能加载文件，不知道问题在哪
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_0.ply')    #32348
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_30.ply')   #29829
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_60.ply')   #19822
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_90.ply')   #24106
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_120.ply')  #27400
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_150.ply')  #29231
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_180.ply')  #29342
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_210.ply')  #28974
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_240.ply')  #25603
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_270.ply') #21359
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_300.ply') #28986
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Armadillo\ArmadilloOnHead\ArmadilloOnHeadMultiple_330.ply') #32803
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12]
    return pc

def load_dragon():
    stand = load_dragon_stand()
    up = load_dragon_up()
    side = load_dragon_side()
    dragon = stand + up + side
    return dragon

def load_dragon_stand():   # 不能加载文件，不知道问题在哪
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_0.pcd')    #40975
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_24.pcd')   #34136
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_48.pcd')   #21665
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_72.pcd')   #14477
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_96.pcd')   #20261
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_120.pcd')  #33735
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_144.pcd')  #42264
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_168.pcd')  #43479
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_192.pcd')  #38587
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_216.pcd') #30423
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_240.pcd') #18879
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_264.pcd') #15024
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_288.pcd')  #39781
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_312.pcd')  #39694
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_stand\dragonStandRight_336.pcd')  #42336
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15]
    # paint_color(pc)
    return pc

def load_dragon_up():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_0.pcd')
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_24.pcd')
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_48.pcd')
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_72.pcd')
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_96.pcd')
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_120.pcd')
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_144.pcd')
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_168.pcd')
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_192.pcd')
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_216.pcd')
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_240.pcd')
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_264.pcd')
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_288.pcd')
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_312.pcd')
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_up\dragonUpRight_336.pcd')
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15]
    paint_color(pc)
    return pc

def load_dragon_side():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_0.pcd')
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_24.pcd')
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_48.pcd')
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_72.pcd')
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_96.pcd')
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_120.pcd')
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_144.pcd')
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_168.pcd')
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_192.pcd')
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_216.pcd')
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_240.pcd')
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_264.pcd')
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_288.pcd')
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_312.pcd')
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Dragon\dragon_side\dragonSideRight_336.pcd')
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15]
    paint_color(pc)
    return pc

def load_buddha_stand():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_0.pcd')    #75669
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_24.pcd')   #73697
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_48.pcd')   #67564
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_72.pcd')   #60304
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_96.pcd')   #60877
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_120.pcd')  #77126
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_144.pcd')  #82626
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_168.pcd')  #82734
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_192.pcd')  #78476
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_216.pcd') #69500
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_240.pcd') #59031
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_264.pcd') #61545
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_288.pcd')  #70349
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_312.pcd')  #73835
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_stand\happyStandRight_336.pcd')  #76940
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15]
    # paint_color(pc)
    return pc

def load_buddha_side():
    pc1  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_0.pcd')    #75669
    pc2  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_24.pcd')   #73697
    pc3  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_48.pcd')   #67564
    pc4  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_72.pcd')   #60304
    pc5  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_96.pcd')   #60877
    pc6  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_120.pcd')  #77126
    pc7  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_144.pcd')  #82626
    pc8  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_168.pcd')  #82734
    pc9  = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_192.pcd')  #78476
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_216.pcd') #69500
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_240.pcd') #59031
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_264.pcd') #61545
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_288.pcd')  #70349
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_312.pcd')  #73835
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Buddha\happy_side\happySideRight_336.pcd')  #76940
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15]
    # paint_color(pc)
    return pc

def load_bunny():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun000.ply')
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun045.ply')
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun090.ply')
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun180.ply')
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun270.ply')
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\bun315.ply')
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\chin.ply')
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\ear_back.ply')
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\top2.ply')
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\bunny\data\top3.ply')
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10]
    # pc = [pc1, pc2, pc3]
    # paint_color(pc)
    return pc

def load_buste():
    pc1 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_00_08_1C.ply')
    pc2 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_00_08_2C.ply')
    pc3 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_00_08_3C.ply')
    pc4 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_00_08_4C.ply')
    pc5 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_45_08_1C.ply')
    pc6 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_45_08_2C.ply')
    pc7 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_45_08_3C.ply')
    pc8 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste1_45_08_4C.ply')
    pc9 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_00_08_1C.ply')
    pc10 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_00_08_2C.ply')
    pc11 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_00_08_3C.ply')
    pc12 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_00_08_4C.ply')
    pc13 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_45_08_1C.ply')
    pc14 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_45_08_2C.ply')
    pc15 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_45_08_3C.ply')
    pc16 = o3d.io.read_point_cloud(r'D:\Datasets\Buste\buste_scandata\buste2_45_08_4C.ply')
    pc = [pc1, pc2, pc3, pc4, pc5, pc6, pc7, pc8, pc9, pc10, pc11, pc12, pc13, pc14, pc15, pc16]
    paint_color(pc)
    return pc

def Statistical_outlier_removal(point_cloud, nb_neighbors=10, std_ratio=2):
    cl, ind = point_cloud.remove_statistical_outlier(nb_neighbors=nb_neighbors, std_ratio=std_ratio)
    return point_cloud.select_by_index(ind)

def Radius_outlier_removal(point_cloud, nb_points=10, radius=0.05):
    cl, ind = point_cloud.remove_radius_outlier(nb_points=nb_points, radius=radius)
    return point_cloud.select_by_index(ind)

def display_inlier_outlier(cloud, ind):
    inlier_cloud = cloud.select_by_index(ind)
    outlier_cloud = cloud.select_by_index(ind, invert=True)

    print("Showing outliers (red) and inliers (gray): ")
    outlier_cloud.paint_uniform_color([1, 0, 0])
    inlier_cloud.paint_uniform_color([0.8, 0.8, 0.8])
    o3d.visualization.draw_geometries([inlier_cloud, outlier_cloud])

if __name__ == '__main__':

    bunny = load_bunny()
    # for i in range(10):
    #     o3d.visualization.draw_geometries([bunny[i]])
    bunny[0].paint_uniform_color([1, 0, 0])
    bunny[2].paint_uniform_color([0, 1, 0])
    # bunny[6].paint_uniform_color([0, 0, 1])
    # for i in range(10):
    #     bunny[i].paint_uniform_color(np.random.random(3))
        # o3d.visualization.draw_geometries([bunny[i]])
    # o3d.visualization.draw_geometries([bunny[0], bunny[2], bunny[6]])
    # o3d.visualization.draw_geometries([bunny[0]])
    # o3d.visualization.draw_geometries([bunny[2]])
    # o3d.visualization.draw_geometries([bunny[6]])
    gt = np.load(r'D:\Datasets\bunny\data\gtT.npz')
    t0 = gt['t_000']
    t2 = gt['t_090']
    bunny[2].transform(t2)
    o3d.visualization.draw_geometries([bunny[0], bunny[2]])
    # t6 = gt['t_chin']
    # # print(t2)
    # print(gt['t_000'])
    # print(gt['t_045'])
    # bunny[0].transform(gt['t_000'])
    # bunny[1].transform(gt['t_045'])
    # o3d.visualization.draw_geometries([bunny[0], bunny[1]])
    # bunny[2].transform(t2)
    # bunny[6].transform(t6)
    # o3d.visualization.draw_geometries([bunny[0], bunny[2], bunny[6]])

    # gt = np.load(r'D:\Datasets\Buddha\happy_side\gtT.npz')
    # t1 = gt['t_0']
    # t2 = gt['t_24']
    # t3 = gt['t_48']
    # t4 = gt['t_72']
    # t5 = gt['t_96']
    # t6 = gt['t_120']
    # t7 = gt['t_144']
    # t8 = gt['t_168']
    # t9 = gt['t_192']
    # t10 = gt['t_216']
    # t11 = gt['t_240']
    # t12 = gt['t_264']
    # t13 = gt['t_288']
    # t14 = gt['t_312']
    # t15 = gt['t_336']
    # t = [t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15]
    # # for i in range(15):
    # #     # buddha_side[i].paint_uniform_color(np.random.random(3))
    # #     buddha_side[i].transform(t[i])
    #
    # sampled = []
    # for i in range(15):
    #     sampled.append(Sample.farthest_down_sample(buddha_side[i], 0.1))
    #     print(sampled[i])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_0.pcd', sampled[0])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_24.pcd', sampled[1])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_48.pcd', sampled[2])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_72.pcd', sampled[3])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_96.pcd', sampled[4])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_120.pcd', sampled[5])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_144.pcd', sampled[6])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_168.pcd', sampled[7])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_192.pcd', sampled[8])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_216.pcd', sampled[9])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_240.pcd', sampled[10])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_264.pcd', sampled[11])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_288.pcd', sampled[12])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_312.pcd', sampled[13])
    # o3d.io.write_point_cloud(r'D:\Datasets\experiments\buddha\buddha_side_0.1\buddha_side_336.pcd', sampled[14])
    # o3d.visualization.draw_geometries(sampled)
    # o3d.visualization.draw_geometries(buddha_side)
