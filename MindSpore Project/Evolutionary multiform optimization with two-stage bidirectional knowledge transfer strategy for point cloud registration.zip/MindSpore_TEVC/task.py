class Task(object):
    def __init__(self, dim,pc1,pc2,norm_pc1,norm_pc2,kdtree,fncobj, ub, lb):
        self.dim = dim
        self.pc1 = pc1
        self.pc2 = pc2
        self.norm_pc1 = norm_pc1
        self.norm_pc2 = norm_pc2
        self.kdtree = kdtree
        self.fncobj = fncobj
        self.lb = lb
        self.ub = ub

    def decode(self, rnvec):
        # nvars = rnvec[:self.dim]
        return self.lb + rnvec * (self.ub - self.lb)

    def encode(self, vec):
        return (vec - self.lb)/(self.ub - self.lb)

