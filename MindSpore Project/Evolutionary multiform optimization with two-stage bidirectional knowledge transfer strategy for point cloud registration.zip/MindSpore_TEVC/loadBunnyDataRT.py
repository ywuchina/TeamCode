import copy
import scipy.io as sio
import os
import open3d as o3d
import mindspore.numpy
def mat2python(filename, flags):
    path = os.path.abspath(os.path.dirname(__file__))
    file = path + filename
    data = sio.loadmat(file)
    names = ['data', 'GrtR', 'GrtT',]
    parameters = []
    for i, flag in enumerate(flags):
        if flag!= None:
            name = names[i]
            parameters.append(data[name])
        else:
            parameters.append(None)
    return parameters

def BUNNY_DATA(filename = '\Bunny.mat'):
    flags = ['data', 'GrtR', 'GrtT', ]
    points_data_GrtR_GrtT = mat2python(filename, flags)
    return points_data_GrtR_GrtT[0],points_data_GrtR_GrtT[1],points_data_GrtR_GrtT[2]