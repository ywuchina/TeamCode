import math
import os
import mindspore.numpy
from mindspore import context, ParallelMode
from mindspore.communication.management import init
from numpy import mean
import numpy as np
from MindSpore_TEVC.CommonFunctions.Loca_normalization import Loca_normalization
from MindSpore_TEVC.CommonFunctions.cal_md import cal_md
from MindSpore_TEVC.CommonFunctions.calc_error import calc_error
from MindSpore_TEVC.CommonFunctions.knnsearch import KDTree
from MindSpore_TEVC.CommonFunctions.obtain_p import obtain_p
from MindSpore_TEVC.CommonFunctions.pcFarthestPointSample import pcFarthestPointSample
from MindSpore_TEVC.CommonFunctions.rigid3d import rigid3d
from MindSpore_TEVC.Loss.CP_loss_cauchy import CP_loss_cauchy
from MindSpore_TEVC.Loss.CP_loss_huber import CP_loss_huber
from MindSpore_TEVC.MFEA.mfea import mfea
from MindSpore_TEVC.CommonFunctions.farthest_down_sample import farthest_down_sample
from MindSpore_TEVC.loadBunnyDataRT import *
from MindSpore_TEVC.task import Task
import time
seed = mindspore.get_seed()
context.set_auto_parallel_context(parallel_mode=ParallelMode.AUTO_PARALLEL,gradients_mean=True)
# context.set_auto_parallel_context(parallel_mode=ParallelMode.DATA_PARALLEL, gradients_mean=True)
context.set_context(mode=context.GRAPH_MODE)
init()

start_time = time.time()
'''
param setting
'''
target = 0
source = 1
half_gen = 1
mu= 0.5
sigma=0.6
pop=100
gen=60 #60
selection_pressure = 'roulette wheel'
p_il = 0
rmp=0.5
data,GrtR,GrtT=BUNNY_DATA()
scannum= data.shape[1]-8
sample_ration=0.05
rot_m  =np.eye(3)
sample_pc=[o3d.geometry.PointCloud(),o3d.geometry.PointCloud()]
norm_pcs=[o3d.geometry.PointCloud(),o3d.geometry.PointCloud()]
norm_trans=list()
norm_trans.append(np.zeros((1,3)))
norm_trans.append(np.zeros((1,3)))
pcd_o3d_list=[o3d.geometry.PointCloud(),o3d.geometry.PointCloud()]
for i in range(scannum):
   pcd_o3d = o3d.geometry.PointCloud()
   pcd_o3d.points = o3d.utility.Vector3dVector(data[0][i].T)
   pcd_o3d_list[i] = pcd_o3d
   cl, ind = pcd_o3d_list[i].remove_statistical_outlier(nb_neighbors=4, std_ratio=1)
   pcd_o3d_list[i] = pcd_o3d_list[i].select_by_index(ind)
   sample_pc[i] = farthest_down_sample(pcd_o3d_list[i],sample_ration)
   norm_pcs[i], norm_trans[i] = Loca_normalization(sample_pc[i])
   M = rigid3d(rot_m, -norm_trans[i][0,:])
   pcd_o3d_list[i] = copy.deepcopy(pcd_o3d_list[i]).transform(M)
   GrtT[0][i] = GrtT[0][i] + np.dot(GrtR[0][i],norm_trans[i].T)

for i in range(1,scannum):
   GrtT[0][i] = np.dot(np.linalg.inv(GrtR[0][0]), (GrtT[0][i]-GrtT[0][0]))
   GrtR[0][i] = np.dot(np.linalg.inv(GrtR[0][0]),GrtR[0][i])

GrtT[0][0]=np.zeros((3,1));GrtR[0][0]=np.eye(3)

pc=[o3d.geometry.PointCloud(),o3d.geometry.PointCloud()]
norm_pc=[o3d.geometry.PointCloud(),o3d.geometry.PointCloud()]

pc[0] = pcd_o3d_list[target]  #【model】
pc[1] = pcd_o3d_list[source]  #【data 】
norm_pc[0] = norm_pcs[target] #【model】
norm_pc[1] = norm_pcs[source] #【data】
R = GrtR[0][source]           # 3*3
t = GrtT[0][source]           # 3*1

rotation=4  # 4=-45°~45°
n = 6
l_trans = np.asarray([np.min(np.vstack((np.asarray(norm_pc[0].points),np.asarray(norm_pc[1].points))),0)])
u_trans = np.asarray([np.max(np.vstack((np.asarray(norm_pc[0].points),np.asarray(norm_pc[1].points))),0)])
l_rot = (-np.pi)/rotation * np.ones((1,3))
u_rot = np.pi/rotation * np.ones((1,3))
'''
cauchy
'''
iter_huber = 2*(np.max(u_trans-l_trans,1)[0])
iter_huber_end = 2*cal_md(norm_pc[0].points)
anneal_rate = 10**(np.log10(iter_huber_end/iter_huber)/30.0)
iter = np.log10(iter_huber_end/iter_huber)/np.log10(anneal_rate)

kdtree1 = KDTree(norm_pc[0])
kdtree2 = KDTree(norm_pc[0])
Tasks = [Task(dim=n,pc1=pc[1],pc2=pc[0],
             norm_pc1=norm_pc[1],norm_pc2=norm_pc[0],
             kdtree=kdtree1,fncobj=CP_loss_huber(),ub=np.hstack((u_rot,u_trans)),lb=np.hstack((l_rot,l_trans))),
         Task(dim=n, pc1=pc[1], pc2=pc[0],
              norm_pc1=norm_pc[1], norm_pc2=norm_pc[0],
              kdtree=kdtree2, fncobj=CP_loss_cauchy(), ub=np.hstack((u_rot,u_trans)), lb=np.hstack((l_rot,l_trans)))
         ]
iter_times=1
MFEA_Ours_data= []
r_Initial=[]
t_Initial=[]
r_MFEA1=[]
t_MFEA1=[]
r_MFEA2=[]
t_MFEA2=[]
for i in range(iter_times):
    MFEA_Ours_data.append(0)
    r_Initial.append(0)
    t_Initial.append(0)
    r_MFEA1.append(0)
    t_MFEA1.append(0)
    r_MFEA2.append(0)
    t_MFEA2.append(0)
M_eye_list=[np.eye(4),np.eye(4),np.eye(4)]
print("begin running of MFEA..................................")
for ii in range(iter_times):
   MFEA_Ours_data[ii] = mfea(tasks=Tasks, pop=pop, gen=gen, selection_process=selection_pressure,
                                  rmp=rmp, p_il=p_il,iter_huber=iter_huber,iter_huber_end=iter_huber_end,
                                  anneal_rate=anneal_rate,reps=iter_times)

   M_eye_list[0] = np.eye(4)
   e_r_Initial, e_t_Initial = calc_error(M_eye_list[0][0:3, 0: 3], R, M_eye_list[0][0:3, 3], t)
   r_Initial[ii] = e_r_Initial
   t_Initial[ii] = e_t_Initial

   M_eye_list[1] = obtain_p(MFEA_Ours_data[ii], Tasks, 0, 2)# task1 precise
   e_r_MFEA1, e_t_MFEA1 = calc_error(M_eye_list[1][0:3, 0: 3], R, M_eye_list[1][0:3, 3], t)
   M_eye_list[2] = obtain_p(MFEA_Ours_data[ii], Tasks, 1, 2)# task2 robust
   e_r_MFEA2, e_t_MFEA2 = calc_error(M_eye_list[2][0:3, 0: 3], R, M_eye_list[2][0:3, 3], t)
   r_MFEA1[ii] = e_r_MFEA1
   t_MFEA1[ii] = e_t_MFEA1
   r_MFEA2[ii] = e_r_MFEA2
   t_MFEA2[ii] = e_t_MFEA2
   print("Now iteration :{}".format(ii+1))

print("e_r_Initial = {}      e_t_Initial = {}".format(np.mean(r_Initial),np.mean(t_Initial)))
print("e_r_MFEA1 = {}        e_t_MFEA1 = {}".format(np.mean(r_MFEA1),np.mean(t_MFEA1)))
print("e_r_MFEA2 = {}        e_t_MFEA2 = {}".format(np.mean(t_MFEA2),np.mean(t_MFEA2)))
end_time = time.time()
print("The running time is {} seconds".format(end_time-start_time))
# mindspore.ms_memory_recycle()

'''
Finally, the precise task results are output as the final registration result.
'''
print("precise task rigid matrix:")
print(M_eye_list[1])
print("robust task rigid matrix:")
print(M_eye_list[2])
'''
target pc colors red
registration result of precise task blue(task1)
registration result of robust task green(task2)
'''
after_registration_pcd = copy.deepcopy(norm_pc[source]).transform(M_eye_list[1])
after_registration_pcd.colors = o3d.utility.Vector3dVector(np.asarray([[0,0,1] for i in range(len(after_registration_pcd.points))]))


after_registration_pcd1 = copy.deepcopy(norm_pc[source]).transform(M_eye_list[2])
after_registration_pcd1.colors = o3d.utility.Vector3dVector(np.asarray([[0,1,0] for i in range(len(after_registration_pcd1.points))]))

norm_pc[target].colors = o3d.utility.Vector3dVector(np.asarray([[1,0,0] for i in range(len(norm_pc[target].points))]))

o3d.visualization.draw_geometries([norm_pc[target], after_registration_pcd],window_name="registration of precise task.target is red and source is blue.")
o3d.visualization.draw_geometries([norm_pc[target], after_registration_pcd1],window_name="registration of robust task.target is red and source is green.")