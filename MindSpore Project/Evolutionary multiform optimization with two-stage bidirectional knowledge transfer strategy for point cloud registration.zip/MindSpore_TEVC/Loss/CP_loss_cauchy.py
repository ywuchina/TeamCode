import copy
import numpy as np
# import mindspore.numpy as np
import math
from mindspore.dataset import vision
from mindspore.dataset import MnistDataset, GeneratorDataset
from MindSpore_TEVC.CommonFunctions.eul2rotm import eul2rotm
from MindSpore_TEVC.CommonFunctions.rigid3d import rigid3d

class CP_loss_cauchy():
    def fnc(self,x,iter_huber,norm_pc1,norm_pc2,kdtree):
        angle = x[0, 0:3]
        T = x[0, 3:6]
        R = eul2rotm(angle)
        M = rigid3d(R, T)
        t_pc1 = copy.deepcopy(norm_pc1).transform(M)
        t_pc2 = norm_pc2

        source = t_pc1
        target = t_pc2
        index, dist = kdtree.knnsearch(source)
        w = np.divide( 1,( np.ones(( 1, dist.size )) + ( ( dist.T / iter_huber ) ** 2 ) ) )
        '''
        Loss
        '''
        inlier = np.sum(dist <= iter_huber)
        balance1 = 0.10
        obj = np.mean(w * ((dist.T) ** 2)) + balance1 * np.log(1 + (1 - inlier / dist.size) ** 2)
        print(
            f"Loss2 fir1 = {np.mean(w * ((dist.T) ** 0.5))} Loss2 fir2 = {balance1 * math.log(1 + (1 - inlier / dist.size) ** 2)} obj = {obj}")
        return obj



