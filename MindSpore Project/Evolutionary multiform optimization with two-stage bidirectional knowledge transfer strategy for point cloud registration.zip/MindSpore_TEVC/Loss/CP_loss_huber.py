import copy
import math
import numpy as  np
from MindSpore_TEVC.CommonFunctions.cal_md import cal_md
from MindSpore_TEVC.CommonFunctions.eul2rotm import eul2rotm
from MindSpore_TEVC.CommonFunctions.rigid3d import rigid3d
class CP_loss_huber():
    def fnc(self,x,iter_huber,norm_pc1,norm_pc2,kdtree):
        angle = x[0,0:3]
        T = x[0,3:6]
        R = eul2rotm(angle)
        M = rigid3d(R, T)
        t_pc1 = copy.deepcopy(norm_pc1).transform(M)
        t_pc2 = norm_pc2

        source = t_pc1
        target = t_pc2
        index, dist = kdtree.knnsearch(source)

        # calculate weight
        huber = 2*cal_md(target.points)
        inlier = np.sum(dist <= huber)
        dist[dist > huber] = huber
        obj = math.sqrt(np.mean(dist**0.5))

        print(f"outlier rate = {(1-inlier/dist.size)} obj = {obj}")
        return obj