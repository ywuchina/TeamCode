import copy
import numpy as np
import scipy.optimize as op
from MindSpore_TEVC.CommonFunctions.Micp import Micp
from MindSpore_TEVC.CommonFunctions.eul2rotm import eul2rotm
from MindSpore_TEVC.CommonFunctions.rigid3d import rigid3d
from MindSpore_TEVC.CommonFunctions.rotm2eul import rotm2eul

class Individual(object):

    def __init__(self, D_multitask, tasks):
        self.dim = D_multitask
        self.tasks = tasks
        self.no_of_tasks = len(tasks)

        self.rnvec = np.random.uniform(size=D_multitask)
        self.scalar_fitness = None
        self.skill_factor = None

    def evaluate(self, p_il,method,iter_huber):
        if self.skill_factor == None:
            raise ValueError("skill factor not set")
        else:
            objective = 0
            task = self.tasks[self.skill_factor]
            nvars = self.rnvec[:task.dim]
            vars = task.decode(nvars)
            if np.random.uniform() <= p_il:
                angle = vars[0:3]
                T = vars[3:6]
                R = eul2rotm(angle)
                M = rigid3d(R.T, T)
                t_pc1 = copy.deepcopy(task.pc1).transform(M)
                t_pc2 = task.pc2
                # MICP
                model = np.double(np.transpose(t_pc2.points))
                data = np.double(np.transpose(t_pc1.points))
                RotMat2, TransVec2, dataOut2 = Micp(model, data, [], [], 2)

                M_new = np.array([[RotMat2, TransVec2],[0,0,0,1]])*(np.transpose(M))
                R_new = M_new[0:3, 0:3]
                T_new = M_new[0:3, 3]
                x = rotm2eul(R_new)
                x = np.hstack((x, T_new))
                # res = op.minimize(task.fnc, vars, method=method)
                # x = res.x
                nvars = task.encode(x)
                m_nvars = nvars
                # m_nvars[m_nvars < 0] = 0
                # m_nvars[m_nvars > 1] = 1
                m_nvars[nvars<0]=0
                m_nvars[nvars>1]=1
                if (m_nvars != nvars) != 0:
                    nvars = m_nvars
                    x = task.decode(nvars)
                    objective = task.fncobj.fnc(x,iter_huber,task.norm_pc1,task.norm_pc2,task.kdtree)
                self.rnvec[: task.dim] = nvars
                funcCount = 1
            else:
                x=vars
                objective = task.fncobj.fnc(x,iter_huber,task.norm_pc1,task.norm_pc2,task.kdtree)
                funcCount = 1
        return self.skill_factor, objective, funcCount
