class Data_MFEA():
    def __init__(self,wall_clock_time,TotalEvaluations,bestobj,bestInd_data):
        '''
        :param wall_clock_time: running time
        :param TotalEvaluations: num of evaluation
        :param bestobj: best obj of every gen of every task
        :param bestInd_data: best chromosome of every task
        :param inital_pop: inital_pop
        '''
        self.wall_clock_time = wall_clock_time
        self.TotalEvaluations = TotalEvaluations
        self.bestobj = bestobj
        self.bestInd_data = bestInd_data
        # self.inital_pop = inital_pop
