import numpy as np
import open3d as o3d
def farthest_down_sample(cloud, ratio):
    points = np.asarray(cloud.points)
    N = points.shape[0]
    npoint = int(N * ratio)
    distances = np.full((N,), float('inf'))
    centroids = np.empty((npoint,), dtype=int)
    # farthest = np.random.randint(0, N)
    farthest = 0
    for i in range(npoint):
        centroids[i] = farthest
        centroid = points[farthest]
        dist = np.sum((points - centroid) ** 2, axis=1)
        mask = dist < distances
        distances[mask] = dist[mask]
        farthest = np.argmax(distances)
    new_points = points[centroids]
    new_cloud = o3d.geometry.PointCloud()
    new_cloud.points = o3d.utility.Vector3dVector(new_points)
    return new_cloud