import numpy as np
from MindSpore_TEVC.CommonFunctions.eul2rotm import eul2rotm
from MindSpore_TEVC.CommonFunctions.rigid3d import rigid3d

def obtain_p(data_MorS, Tasks, i, flag):
    if flag == 1:# single task
        vec = data_MorS.bestInd_data[0,i,:]
        str = 'SOO'
        minrange = Tasks[i].lb
        maxrange = Tasks[i].ub
        y = maxrange - minrange
        vars = y * vec + minrange

        angle = vars[0, 0:3]
        T = vars[0, 3:6]
        R = eul2rotm(angle)
        M = rigid3d(R, T)
        return M
    elif flag == 2: # multitasking
        vec = data_MorS.bestInd_data[0,i,:]
        str = 'MFEA'
        minrange = Tasks[i].lb
        maxrange = Tasks[i].ub
        y = maxrange - minrange
        vars = y * vec + minrange

        angle = vars[0, 0:3]
        T = vars[0, 3:6]
        R = eul2rotm(angle)
        M = rigid3d(R, T)
        return M