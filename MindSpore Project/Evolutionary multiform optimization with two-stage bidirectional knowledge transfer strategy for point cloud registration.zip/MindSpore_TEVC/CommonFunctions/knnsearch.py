import open3d as o3d
import numpy as np
class KDTree():
    def __init__(self,pc):
        self.pc = pc
        kdtree = o3d.geometry.KDTreeFlann(pc)
        self.kdtree = kdtree
        self.pointNums = len(pc.points)
    def knnsearch(self,source):
        index_list = np.zeros((len(source.points),1))
        dist_list = np.zeros((len(source.points),1))
        for i in range(len(source.points)):
            k, idx,dist_to_knn = self.kdtree.search_knn_vector_3d(source.points[i], 1)
            index_list[i,0] = idx[0]
            dist_list[i,0] = dist_to_knn[0]
        return index_list,dist_list

