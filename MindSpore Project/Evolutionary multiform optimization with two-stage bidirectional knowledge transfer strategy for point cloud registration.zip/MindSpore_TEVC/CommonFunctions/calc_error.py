import math
import numpy as np
def calc_error(R1,R2,t1,t2):
    e_r = abs(math.acos((np.trace(np.dot(R1.T,R2))-1)/2))
    #（Angular distance between two rotation matrices.）
    e_t = np.linalg.norm(t1 - t2)
    return e_r,e_t
