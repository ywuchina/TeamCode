import numpy as np
import math
def eul2rotm(eul):
    R = np.random.rand(3,3)
    ct = np.cos(eul)
    st = np.sin(eul)
    # The rotation matrix R can be constructed as follows by
    # ct = [cz cy cx] and st = [sy sy sx]
    #
    # R = [cy * cz   sy * sx * cz - sz * cx    sy * cx * cz + sz * sx
           # cy * sz   sy * sx * sz + cz * cx    sy * cx * sz - cz * sx
           # -sy            cy * sx             cy * cx]
    # = Rz(tz) * Ry(ty) * Rx(tx)
    'zyx'
    # R[0, 0] = ct[1]*ct[0]
    # R[0, 1] = st[2]*st[1]*ct[0] - ct[2]*st[0]
    # R[0, 2] = ct[2]*st[1]*ct[0] + st[2]*st[0]
    # R[1, 0] = ct[1]*st[0]
    # R[1, 1] = st[2]*st[1]*st[0] + ct[2]*ct[0]
    # R[1, 2] = ct[2]*st[1]*st[0] - st[2]*ct[0]
    # R[2, 0] = -st[1]
    # R[2, 1] = st[2]*ct[1]
    # R[2, 2] = ct[2]*ct[1]
    'xyz'
    R[0, 0] = ct[1] * ct[2]
    R[0, 1] = -ct[1] * st[2]
    R[0, 2] = st[1]
    R[1, 0] = ct[0] * st[2] + ct[2] * st[0] * st[1]
    R[1, 1] = ct[0] * ct[2] - st[0] * st[1] * st[2]
    R[1, 2] = -ct[1] * st[0]
    R[2, 0] = st[0] * st[2] - ct[0] * ct[2] * st[1]
    R[2, 1] = ct[2] * st[0] + ct[0] * st[1] * st[2]
    R[2, 2] = ct[0] * ct[1]

    return R