import numpy as np
import open3d as o3d
def Loca_normalization(pc):
    location = np.zeros(np.asarray(pc.points).shape)
    np_pc = np.asarray(pc.points)
    T = np.zeros((1,3))
    for i in range(3):
        temp = np.mean(np_pc[:,i])
        T[0,i] = temp
        temp = temp * np.ones((np_pc.shape[0],1))
        location[:, i] = np_pc[:, i] - temp[:,0]
    pcd_o3d = o3d.geometry.PointCloud()
    pcd_o3d.points= o3d.utility.Vector3dVector(location)
    return pcd_o3d,T
