import numpy as np
import math
import open3d as o3d
from scipy.spatial.distance import pdist
def pdist2(t,s):
    d = np.zeros((len(t),1))
    for i in range(len(t)):
        d[i, 0] = np.linalg.norm(s-t[i,:])
    return d
def fps_euclidean(V, n, seed):
    S = np.zeros((n, 1))
    S = S.astype(int)
    S[0,0] = seed-1
    d = pdist2(V, V[seed,:])
    for i in range(1,n):
        m = np.argmax(d)
        S[i,0] = m
        d = np.asarray([np.min(np.hstack((pdist2(V,V[S[i,0],:]), d)),1)]).T
    return S
def pcFarthestPointSample(pc,sampleCount):
    idx_fps = fps_euclidean(np.asarray(pc.points), sampleCount, 1)
    idx_fps = np.sort(idx_fps,axis=0)
    sample_pc = o3d.geometry.PointCloud()
    sample_pc.points = o3d.utility.Vector3dVector(np.asarray(pc.points)[idx_fps[:,],:])
    if np.asarray(pc.colors).size !=0:
        sample_pc.colors = o3d.utility.Vector3dVector(np.asarray(pc.colors)[idx_fps[:,],:])
    x = 1
    if np.asarray(pc.normals).size !=0:
        sample_pc.normals = o3d.utility.Vector3dVector(np.asarray(pc.normals)[idx_fps[:,], :])
    return sample_pc