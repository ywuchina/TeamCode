import numpy as np
import math
from sklearn.neighbors import NearestNeighbors

def cal_md(scan):
    Model = np.asarray(scan)#N*3
    neigh = NearestNeighbors(n_neighbors=2)
    neigh.fit(Model)
    dist, corr = neigh.kneighbors(Model)#dist（NX2） corr（NX2）
    md = math.sqrt(np.mean(dist[:,1]**2))
    return md


