
import numpy as np
def rigid3d(R,T):
    M=np.double(np.zeros((4,4)))
    M[0:3,0:3]=R
    M[0:3,3]=T
    M[3,3]=1
    return M