import numpy as np
import mindspore
from mindspore import Tensor
import mindspore.nn as nn
import mindspore.ops as ops


class STNkd(nn.Cell):
    """STNkd"""

    def __init__(self, k=64):
        super(STNkd, self).__init__()
        self.conv1 = nn.Conv1d(k, 64, 1, has_bias=True, bias_init='normal')
        self.conv2 = nn.Conv1d(64, 128, 1, has_bias=True, bias_init='normal')
        self.conv3 = nn.Conv1d(128, 1024, 1, has_bias=True, bias_init='normal')
        self.fc1 = nn.Dense(1024, 512)
        self.fc2 = nn.Dense(512, 256)
        self.fc3 = nn.Dense(256, k * k)
        # ops是底层算子接口,nn做了封装,其实都一样
        self.relu = ops.ReLU()
        self.flatten = nn.Flatten()
        self.bn1 = nn.BatchNorm2d(64)
        self.bn2 = nn.BatchNorm2d(128)
        self.bn3 = nn.BatchNorm2d(1024)
        self.bn4 = nn.BatchNorm1d(512)
        self.bn5 = nn.BatchNorm1d(256)
        self.k = k

    def construct(self, x):
        """construct equals forward"""
        batchsize = x.shape[0]
        # self.conv1(x)->[batch,channel,num_pts]
        # 因为mindspore.nn.BatchNorm1d->[N,C],不支持加入batch
        # 所以这里用BatchNorm2d->[N,C,H,W],所以扩展下x->[batch,channel,num_pts,1]
        # 之后再使用Squeeze->[batch,channel,num_pts]
        x = self.relu(ops.Squeeze(-1)(self.bn1(ops.ExpandDims()(self.conv1(x), -1))))
        x = self.relu(ops.Squeeze(-1)(self.bn2(ops.ExpandDims()(self.conv2(x), -1))))
        x = self.relu(ops.Squeeze(-1)(self.bn3(ops.ExpandDims()(self.conv3(x), -1))))
        x = ops.ArgMaxWithValue(axis=2, keep_dims=True)(x)[1].view(-1, 1024)
        x = self.relu(self.bn4(self.fc1(x)))
        x = self.relu(self.bn5(self.fc2(x)))
        x = self.fc3(x)
        # torch中的repeat,重复multiples次
        tile = ops.Tile()
        multiples = (batchsize, 1)
        iden = tile(Tensor(np.eye(self.k).flatten().astype(np.float32)).view(1, self.k * self.k), multiples)
        x = x + iden
        x = x.view(-1, self.k, self.k)
        return x


class PointNet(nn.Cell):
    def __init__(self, n_emb_dims):
        super(PointNet, self).__init__()
        self.stn = STNkd(k=64)
        self.conv1 = nn.Conv1d(3, 64, 1, has_bias=False)
        self.conv2 = nn.Conv1d(64, 64, 1, has_bias=False)
        self.conv3 = nn.Conv1d(64, 128, 1, has_bias=False)
        self.conv4 = nn.Conv1d(128, 256, 1, has_bias=False)
        self.conv5 = nn.Conv1d(512, n_emb_dims, 1, has_bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.bn2 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(256)
        self.bn5 = nn.BatchNorm2d(n_emb_dims)
        self.relu = nn.ReLU()
        self.expanddims = ops.ExpandDims()
        self.squeeze = ops.Squeeze(-1)
        self.transpose = ops.Transpose()
        self.batmatmul = ops.BatchMatMul()
        self.cat = ops.Concat(axis=1)

    def construct(self, x):
        x1 = self.relu(self.squeeze(self.bn1(self.expanddims(self.conv1(x), -1))))
        x2 = self.relu(self.squeeze(self.bn2(self.expanddims(self.conv2(x1), -1))))
        trans_feat = self.stn(x2)
        x2 = self.transpose(x2, (0, 2, 1))
        x2 = self.batmatmul(x2, trans_feat)
        x2 = self.transpose(x2, (0, 2, 1))
        x3 = self.relu(self.squeeze(self.bn3(self.expanddims(self.conv3(x2), -1))))
        x4 = self.relu(self.squeeze(self.bn4(self.expanddims(self.conv4(x3), -1))))
        x5 = self.cat((x1, x2, x3, x4))
        x = self.relu(self.squeeze(self.bn5(self.expanddims(self.conv5(x5), -1))))
        return x


if __name__ == '__main__':
    shape1 = (2, 3, 2)
    uniformreal = ops.UniformReal()
    sim_data = uniformreal(shape1)
    ptnet = PointNet(n_emb_dims=1024)
    result = ptnet(sim_data)
    print(result)
