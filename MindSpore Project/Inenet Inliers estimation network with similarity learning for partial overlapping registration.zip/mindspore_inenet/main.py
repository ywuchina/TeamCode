import random
import numpy as np
import mindspore
from mindspore import Tensor, ops
import mindspore.nn as nn
from tensorboardX import SummaryWriter
import transforms3d
from tqdm import tqdm
import sys, os

sys.path.append("..")
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from data_utils import *
from inenet import OverlapNet
from evaluate_funcs import evaluate_mask

if not os.path.isdir("./logs"):
    os.mkdir("./logs")
writer = SummaryWriter('./logs')
batchsize = 32
epochs = 300
lr = 1e-3
num_subsampled_rate = 0.75
unseen = False
noise = False
file_type = 'modelnet40'


def test_one_epoch(net, test_loader, return_t=False):
    net.eval()
    total_loss = 0
    loss_fn = nn.HuberLoss(delta=0.4)
    with ops.stop_gradient():
        count = 0
        accs = []
        preciss = []
        recalls = []
        f1s = []
        for data in tqdm(test_loader):
            src = data["src"]
            target = data["target"]
            rotation = data["rotation"]
            translation = data["translation"]
            euler = data["euler"]
            mask_gt = data["mask_gt"]
            mask_gt_cp = mindspore.numpy.where(mask_gt == 0.0, Tensor(-1.0), Tensor(1.0))
            mask, mask_idx, threshold = net(src, target)
            loss = loss_fn(mask - threshold, mask_gt_cp)

            total_loss += loss.item()
            # 计算准确率
            count += 1
            # 评估
            acc, precis, recall, f1 = evaluate_mask(mask_idx, mask_gt)
            accs.append(acc)
            preciss.append(precis)
            recalls.append(recall)
            f1s.append(f1)
        acc = np.mean(accs)
        precis = np.mean(preciss)
        recall = np.mean(recalls)
        f1 = np.mean(f1s)
    if return_t:
        return total_loss, acc, precis, recall, f1, ops.ReduceMean()(threshold).item()

    return total_loss, acc, precis, recall, f1


def train_one_epoch(net, opt, train_loader, return_t=False):
    net.train()
    total_loss = 0
    count = 0
    accs = []
    preciss = []
    recalls = []
    f1s = []
    loss_fn = nn.HuberLoss(delta=0.4)

    for data in tqdm(train_loader):
        src = data["src"]
        target = data["target"]
        rotation = data["rotation"]
        translation = data["translation"]
        euler = data["euler"]
        mask_gt = data["mask_gt"]
        # print(src.shape, target.shape)
        # 用于计算损失的阈值，mask_gt用于计算准确率
        mask_gt_cp = mindspore.numpy.where(mask_gt == 0.0, Tensor(-1.0), Tensor(1.0))
        mask, mask_idx, threshold = net(src, target)

        opt.zero_grad()
        loss = loss_fn(mask - threshold, mask_gt_cp)
        total_loss += loss.item()
        loss.backward()
        opt.step()

        # 计算准确率
        count += 1
        # 评估
        acc, precis, recall, f1 = evaluate_mask(mask_idx, mask_gt)
        accs.append(acc)
        preciss.append(precis)
        recalls.append(recall)
        f1s.append(f1)
    acc = np.mean(accs)
    precis = np.mean(preciss)
    recall = np.mean(recalls)
    f1 = np.mean(f1s)

    if return_t:
        return total_loss, acc, precis, recall, f1, ops.ReduceMean()(threshold).item()

    return total_loss, acc, precis, recall, f1


if __name__ == '__main__':

    best_loss = np.inf
    best_acc = 0

    train_dataset_generator = ModelNet40_Reg_Generator(
        num_subsampled_rate=num_subsampled_rate,
        partition='train',
        max_angle=45,
        max_t=0.5,
        noise=noise,
        partial_source=True,
        unseen=unseen,
        file_type=file_type
    )
    train_dataset = ds.GeneratorDataset(train_dataset_generator,
                                        ["src", "target", "rotation", "translation", "euler", "mask_gt"])
    train_dataset = train_dataset.batch(batchsize=batchsize)
    train_loader = train_dataset.create_dict_iterator()

    test_dataset_generator = ModelNet40_Reg_Generator(
        num_subsampled_rate=num_subsampled_rate,
        partition='test',
        max_angle=45,
        max_t=0.5,
        noise=noise,
        partial_source=True,
        unseen=unseen,
        file_type=file_type
    )
    test_dataset = ds.GeneratorDataset(test_dataset_generator,
                                       ["src", "target", "rotation", "translation", "euler", "mask_gt"])
    test_dataset = test_dataset.batch(batchsize=batchsize)
    test_loader = test_dataset.create_dict_iterator()

    if file_type == 'modelnet40':
        num_subsampled_points = int(num_subsampled_rate * 1024)
    elif file_type == 'S3DIS':
        num_subsampled_points = int(num_subsampled_rate * 2048)
    elif file_type in ['3DMatch', 'Apollo', 'bunny']:
        num_subsampled_points = int(num_subsampled_rate * 4096)
    else:
        num_subsampled_points = 768

    net = OverlapNet(num_subsampled_points=num_subsampled_points)
    opt = nn.AdamWeightDecay(params=net.parameters(), learning_rate=lr)
    # 动态调整学习率
    # scheduler = MultiStepLR(opt, milestones=[50, 100, 150], gamma=0.1)

    start_epoch = -1
    RESUME = False  # 是否加载模型继续上次训练
    if RESUME:
        path_checkpoint = "./checkpoint/ckpt%s.pth" % (str(file_type) + str(num_subsampled_points))  # 断点路径
        checkpoint = mindspore.load_checkpoint(path_checkpoint)  # 加载断点
        net.load_state_dict(checkpoint['net'])  # 加载模型可学习参数
        # scheduler.load_state_dict(checkpoint["lr_step"])
        opt.load_state_dict(checkpoint['optimizer'])  # 加载优化器参数
        start_epoch = checkpoint['epoch']  # 设置开始的epoch
        # 加载上次best结果
        best_loss = checkpoint['best_loss']
        best_acc = checkpoint['best_acc']
        best_recall = checkpoint['best_recall']
        best_precis = checkpoint['best_precis']
        best_f1 = checkpoint['best_f1']

    for epoch in range(start_epoch + 1, epochs):
        train_loss, train_acc, train_precis, train_recall, train_f1, train_threshold = train_one_epoch(net, opt,
                                                                                                       train_loader,
                                                                                                       return_t=True)
        test_loss, test_acc, test_precis, test_recall, test_f1, test_threshold = test_one_epoch(net, test_loader,
                                                                                                return_t=True)
        # scheduler.step()
        if test_acc >= best_acc:
            best_loss = test_loss
            best_acc = test_acc
            best_precis = test_precis
            best_recall = test_recall
            best_f1 = test_f1
            # 保存最好的checkpoint
            checkpoint_best = {
                "net": net.state_dict(),
            }
            if not os.path.isdir("./checkpoint"):
                os.mkdir("./checkpoint")
            mindspore.save_checkpoint(checkpoint_best, './checkpoint/ckpt_best%s.pth' % (str(file_type) + str(num_subsampled_points)))

        print('---------Epoch: %d---------' % (epoch + 1))
        print('Train: Loss: %f, Acc: %f, Precis: %f, Recall: %f, F1: %f'
              % (train_loss, train_acc, train_precis, train_recall, train_f1))

        print('Test: Loss: %f, Acc: %f, Precis: %f, Recall: %f, F1: %f'
              % (test_loss, test_acc, test_precis, test_recall, test_f1))

        print('Best: Loss: %f, Acc: %f, Precis: %f, Recall: %f, F1: %f'
              % (best_loss, best_acc, best_precis, best_recall, best_f1))
        writer.add_scalar('Train/train loss', train_loss, global_step=epoch)
        writer.add_scalar('Train/train Acc', train_acc, global_step=epoch)
        writer.add_scalar('Train/train Precis', train_precis, global_step=epoch)
        writer.add_scalar('Train/train Recall', train_recall, global_step=epoch)
        writer.add_scalar('Train/train F1', train_f1, global_step=epoch)
        writer.add_scalar('Train/train threshold', train_threshold, global_step=epoch)

        writer.add_scalar('Test/test loss', test_loss, global_step=epoch)
        writer.add_scalar('Test/test Acc', test_acc, global_step=epoch)
        writer.add_scalar('Test/test Precis', test_precis, global_step=epoch)
        writer.add_scalar('Test/test Recall', test_recall, global_step=epoch)
        writer.add_scalar('Test/test F1', test_f1, global_step=epoch)
        writer.add_scalar('Test/test threshold', test_threshold, global_step=epoch)

        writer.add_scalar('Best/best loss', best_loss, global_step=epoch)
        writer.add_scalar('Best/best Acc', best_acc, global_step=epoch)
        writer.add_scalar('Best/best Precis', best_precis, global_step=epoch)
        writer.add_scalar('Best/best Recall', best_recall, global_step=epoch)
        writer.add_scalar('Best/best F1', best_f1, global_step=epoch)

        # 保存checkpoint
        checkpoint = {
            "net": net.state_dict(),
            'optimizer': opt.state_dict(),
            "epoch": epoch,
            # "lr_step": scheduler.state_dict(),
            "best_loss": best_loss,
            'best_acc': best_acc,
            'best_recall': best_recall,
            'best_precis': best_precis,
            'best_f1': best_f1,
        }
        if not os.path.isdir("./checkpoint"):
            os.mkdir("./checkpoint")
        mindspore.save_checkpoint(checkpoint, './checkpoint/ckpt%s.pth' % (str(file_type) + str(num_subsampled_points)))
    writer.close()

#
