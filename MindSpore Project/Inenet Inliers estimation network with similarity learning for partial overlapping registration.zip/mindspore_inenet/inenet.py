import numpy as np
import mindspore
from mindspore import Tensor
import mindspore.nn as nn
import mindspore.ops as ops

from feat_extract import STNkd, PointNet

mindspore.set_context(mode=mindspore.PYNATIVE_MODE)


class TPNet(nn.Cell):

    def __init__(self, n_emb_dims):
        super(TPNet, self).__init__()
        self.emb_dims = n_emb_dims
        self.fc1 = nn.Dense(self.emb_dims, 512)
        self.fc2 = nn.Dense(512, 256)
        self.fc3 = nn.Dense(256, 128)
        self.fc4 = nn.Dense(128, 1)
        self.bn1 = nn.BatchNorm1d(512)
        self.bn2 = nn.BatchNorm1d(256)
        self.bn3 = nn.BatchNorm1d(128)
        self.leaky_relu = nn.LeakyReLU(alpha=0.01)
        self.sigmoid = nn.Sigmoid()

    def construct(self, x):
        # x->[batch,channel]
        x = self.leaky_relu(self.bn1(self.fc1(x)))
        x = self.leaky_relu(self.bn2(self.fc2(x)))
        x = self.leaky_relu(self.bn3(self.fc3(x)))
        x = self.fc4(x)
        x = self.sigmoid(x)
        # x->[batch,1]
        return x


class MaskNN(nn.Cell):
    def __init__(self, num_subsampled_points):
        super(MaskNN, self).__init__()
        self.num_subsampled_points = num_subsampled_points
        self.conv1 = nn.Conv1d(self.num_subsampled_points, 1024, 1)
        self.conv2 = nn.Conv1d(1024, 512, 1)
        self.conv3 = nn.Conv1d(512, 128, 1)
        self.conv4 = nn.Conv1d(128, 128, 1)
        self.conv5 = nn.Conv1d(128, 1, 1)
        self.bn1 = nn.BatchNorm2d(1024)
        self.bn2 = nn.BatchNorm2d(512)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(128)
        self.sigmoid = nn.Sigmoid()
        self.leaky_relu = nn.LeakyReLU(alpha=0.01)
        self.expanddims = ops.ExpandDims()
        self.squeeze = ops.Squeeze(-1)

    def construct(self, x):
        x = self.leaky_relu(self.squeeze(self.bn1(self.expanddims(self.conv1(x), -1))))
        x = self.leaky_relu(self.squeeze(self.bn2(self.expanddims(self.conv2(x), -1))))
        x = self.leaky_relu(self.squeeze(self.bn3(self.expanddims(self.conv3(x), -1))))
        x = self.leaky_relu(self.squeeze(self.bn4(self.expanddims(self.conv4(x), -1))))
        x = self.sigmoid(self.conv5(x))
        return x


class OverlapNet(nn.Cell):
    def __init__(self, num_subsampled_points, n_emb_dims=1024):
        super(OverlapNet, self).__init__()
        self.stn = STNkd(k=3)
        self.transpose = ops.Transpose()
        self.batmatmul = ops.BatchMatMul()
        self.emb_dims = n_emb_dims
        self.emb_nn = PointNet(n_emb_dims=self.emb_dims)
        # 第二个点云的点数(缺失点云的点数)
        self.num_subsampled_points = num_subsampled_points
        self.threshold_nn = TPNet(n_emb_dims=n_emb_dims)
        self.mask_nn = MaskNN(num_subsampled_points=num_subsampled_points)
        self.norm = ops.LpNorm(axis=1)
        self.matmul = ops.BatchMatMul()
        self.mean=ops.ReduceMean()
        self.abs=ops.Abs()

    def construct(self, *input):
        src = input[0]  # 1024
        tgt = input[1]  # 768

        trans_src = self.stn(src)
        trans_tgt = self.stn(tgt)

        src = self.transpose(src, (0, 2, 1))
        src = self.batmatmul(src, trans_src)
        src = self.transpose(src, (0, 2, 1))
        tgt = self.transpose(tgt, (0, 2, 1))
        tgt = self.batmatmul(tgt, trans_tgt)
        tgt = self.transpose(tgt, (0, 2, 1))

        src_embedding = self.emb_nn(src)
        tgt_embedding = self.emb_nn(tgt)

        batch_size, num_dims, num_points1 = src_embedding.shape
        batch_size, num_dims, num_points2 = tgt_embedding.shape

        src_norm = src_embedding / (self.norm(src_embedding).reshape(batch_size, 1, num_points1))
        tar_norm = tgt_embedding / (self.norm(tgt_embedding).reshape(batch_size, 1, num_points2))
        # (batch, num_points2, num_points1)->[2,768,1024]
        cos_simi = self.matmul(self.transpose(tar_norm, (0, 2, 1)), src_norm)

        src_glob = self.mean(src_embedding, axis=2)
        tar_glob = self.mean(tgt_embedding, axis=2)
        glob_residual = self.abs(src_glob - tar_glob)

        threshold = self.threshold_nn(glob_residual)
        mask = self.mask_nn(cos_simi).reshape(batch_size, -1)
        mask_idx = mindspore.numpy.where(mask >= threshold, Tensor(1), Tensor(0))
        return mask, mask_idx, threshold


if __name__ == '__main__':
    # shape1 = (2, 1024)
    # uniformreal = ops.UniformReal()
    # sim_data = uniformreal(shape1)
    # tp = TPNet(n_emb_dims=1024)
    # result = tp(sim_data)

    # shape1 = (2, 768, 4)
    # uniformreal = ops.UniformReal()
    # sim_data = uniformreal(shape1)
    # mask = MaskNN(num_subsampled_points=768)
    # result = mask(sim_data)

    src_shape = (2, 3, 1024)
    tgt_shape = (2, 3, 768)
    uniformreal = ops.UniformReal()
    src_data = uniformreal(src_shape)
    tgt_data = uniformreal(tgt_shape)
    overlap = OverlapNet(num_subsampled_points=768)
    result = overlap(src_data, tgt_data)
